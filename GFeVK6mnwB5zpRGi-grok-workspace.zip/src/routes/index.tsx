import { createFileRoute } from "@tanstack/react-router";
import { ZadanApp } from "@/components/zadan-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <ZadanApp />;
}
