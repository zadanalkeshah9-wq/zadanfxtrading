import { create } from "zustand";
import { persist } from "zustand/middleware";

export type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  pending?: boolean;
};

export type JournalTrade = {
  id: string;
  symbol: string;
  nameAr: string;
  side: "buy" | "sell";
  entryLow: number;
  entryHigh: number;
  sl: number;
  tp1: number;
  tp2: number;
  openedAt: number;
  tp1Hit: boolean;
  result: "open" | "win" | "loss" | "partial";
  closedAt?: number;
};

type DeskState = {
  messages: ChatMessage[];
  journal: JournalTrade[];
  alertsOn: boolean;
  speakOn: boolean;
  seenAlerts: string[];
  bannerDismissed: boolean;
  addMessage: (message: ChatMessage) => void;
  patchMessage: (id: string, patch: Partial<ChatMessage>) => void;
  clearChat: () => void;
  trackTrade: (trade: JournalTrade) => void;
  review: (quotes: { id: string; bid: number; ask: number }[]) => void;
  setAlerts: (value: boolean) => void;
  setSpeak: (value: boolean) => void;
  markAlert: (id: string) => void;
  dismissBanner: () => void;
};

export const useDesk = create<DeskState>()(
  persist(
    (set) => ({
      messages: [],
      journal: [],
      alertsOn: true,
      speakOn: true,
      seenAlerts: [],
      bannerDismissed: false,
      addMessage: (message) =>
        set((state) => ({ messages: [...state.messages, message].slice(-40) })),
      patchMessage: (id, patch) =>
        set((state) => ({
          messages: state.messages.map((message) => (message.id === id ? { ...message, ...patch } : message)),
        })),
      clearChat: () => set({ messages: [] }),
      trackTrade: (trade) =>
        set((state) => {
          if (state.journal.some((item) => item.id === trade.id || (item.symbol === trade.symbol && item.result === "open"))) {
            return state;
          }
          return { journal: [trade, ...state.journal].slice(0, 30) };
        }),
      review: (quotes) =>
        set((state) => {
          let changed = false;
          const journal = state.journal.map((trade) => {
            if (trade.result === "win" || trade.result === "loss" || trade.closedAt) return trade;
            const quote = quotes.find((item) => item.id === trade.symbol);
            if (!quote) return trade;
            const hit = trade.side === "buy" ? quote.bid : quote.ask;
            let next = trade;
            if (!trade.tp1Hit && ((trade.side === "buy" && hit >= trade.tp1) || (trade.side === "sell" && hit <= trade.tp1))) {
              next = { ...trade, tp1Hit: true, result: "partial" };
            }
            if ((trade.side === "buy" && hit >= trade.tp2) || (trade.side === "sell" && hit <= trade.tp2)) {
              changed = true;
              return { ...next, result: "win" as const, closedAt: Date.now() };
            }
            const stopped = trade.side === "buy" ? hit <= trade.sl : hit >= trade.sl;
            if (stopped && !next.tp1Hit) {
              changed = true;
              return { ...next, result: "loss" as const, closedAt: Date.now() };
            }
            if (stopped && next.tp1Hit) {
              changed = true;
              return { ...next, result: "partial" as const, closedAt: Date.now() };
            }
            if (next !== trade) changed = true;
            return next;
          });
          return changed ? { journal } : state;
        }),
      setAlerts: (alertsOn) => set({ alertsOn }),
      setSpeak: (speakOn) => set({ speakOn }),
      markAlert: (id) =>
        set((state) => ({ seenAlerts: state.seenAlerts.includes(id) ? state.seenAlerts : [...state.seenAlerts, id].slice(-40) })),
      dismissBanner: () => set({ bannerDismissed: true }),
    }),
    { name: "zadan-fx-desk", skipHydration: true },
  ),
);
