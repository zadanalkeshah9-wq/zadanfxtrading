import type { CalEvent, Quote, Signal } from "@/lib/market-types";
import { fmtPct, fmtPrice, WATCH_BY_ID } from "@/lib/symbols";

const DISCLAIMER = "هذا تحليل تعليمي وليس توصية ملزمة. الخسارة جزء من السوق، ولا توجد صفقة مضمونة.";

export function isPriceQuestion(text: string): boolean {
  const asksPrice = /سعر|كم |بكام|بكم|quote|price/i.test(text);
  const asksPlan = /صفقة|تحليل|دخول|وقف|هدف|شراء|بيع|موج|خبر|لين|لماذا|ليش|اشرح|هل/i.test(text);
  return asksPrice && !asksPlan;
}

function sideLabel(signal: Signal): string {
  if (signal.side === "buy") return "شراء";
  if (signal.side === "sell") return "بيع";
  return "انتظار";
}

export function formatSignalReply(quote: Quote, signal: Signal, events: CalEvent[]): string {
  const name = WATCH_BY_ID[quote.id]?.nameAr ?? quote.id;
  const px = (value: number) => fmtPrice(value, quote.digits);
  const upcoming = events.find((event) => event.impact === "High" && event.time > Date.now());
  const lines = [
    `${name} الآن: شراء ${px(quote.bid)} / بيع ${px(quote.ask)} · اليوم ${fmtPct(quote.changePct)}`,
    `القرار: ${sideLabel(signal)} · التوافق ${signal.score} من ${signal.maxScore} (المطلوب ${signal.minScore})`,
    `الميل اللحظي: ${signal.lean === "buy" ? "صاعد" : signal.lean === "sell" ? "هابط" : "محايد"} · ${signal.session}`,
  ];
  if (signal.side === "wait") {
    lines.push("ما في صفقة بجودة كافية هلق. الدخول بالقوة هنا يرفع احتمال الخسارة.");
    if (signal.lean === "flat") {
      lines.push("الاتجاه غير واضح. انتظر كسراً مؤكداً للقمة أو للقاع قبل أي دخول.");
    } else if (signal.lean === "sell") {
      lines.push(`خطة مشروطة للبيع إذا ثبت الرفض: الدخول ${px(signal.entryLow)} – ${px(signal.entryHigh)}. الوقف ${px(signal.sl)}. الهدف الأول ${px(signal.tp1)} والثاني ${px(signal.tp2)}.`);
    } else {
      lines.push(`خطة مشروطة للشراء إذا ثبت الارتداد: الدخول ${px(signal.entryLow)} – ${px(signal.entryHigh)}. الوقف ${px(signal.sl)}. الهدف الأول ${px(signal.tp1)} والثاني ${px(signal.tp2)}.`);
    }
  } else {
    lines.push(`منطقة الدخول: ${px(signal.entryLow)} – ${px(signal.entryHigh)}`);
    lines.push(`وقف الخسارة: ${px(signal.sl)}`);
    lines.push(`جني الأرباح: ${px(signal.tp1)} ثم ${px(signal.tp2)}`);
    lines.push(`الإلغاء: إغلاق شمعة ٥ دقائق خلف الوقف، أو تغيّر البنية المذكورة.`);
  }
  if (signal.support != null || signal.resistance != null) {
    lines.push(`دعم ${signal.support != null ? px(signal.support) : "—"} · مقاومة ${signal.resistance != null ? px(signal.resistance) : "—"}`);
  }
  if (signal.reasons.length) lines.push(`ما يدعم الفكرة: ${signal.reasons.slice(0, 3).join("، ")}.`);
  if (signal.blockers.length) lines.push(`ما يمنع الثقة: ${signal.blockers.slice(0, 3).join("، ")}.`);
  lines.push(...signal.schools.map((school) => `${school.name}: ${school.note}`));
  if (upcoming) lines.push(`قبل الخبر: ${upcoming.titleAr} (${upcoming.countryAr}). ${upcoming.goldNote}`);
  lines.push(DISCLAIMER);
  return lines.join("\n");
}

export function formatPriceReply(quote: Quote): string {
  const name = quote.nameAr;
  return [
    `${name}: سعر الشراء ${fmtPrice(quote.bid, quote.digits)} وسعر البيع ${fmtPrice(quote.ask, quote.digits)}.`,
    `السبريد ${fmtPrice(quote.spread, quote.digits)}${quote.unit ? ` · ${quote.unit}` : ""}.`,
    `تغير اليوم ${fmtPct(quote.changePct)}.`,
    "الرقم لحظي من مزود الأسعار طالما الاتصال شغّال.",
  ].join("\n");
}

export function journalSummary(trades: { result: string; symbol: string; side: string }[]): string {
  if (!trades.length) return "";
  const closed = trades.filter((trade) => trade.result === "win" || trade.result === "loss" || trade.result === "partial");
  const wins = closed.filter((trade) => trade.result === "win" || trade.result === "partial").length;
  const recent = trades
    .slice(0, 5)
    .map((trade) => `${trade.symbol} ${trade.side} ${trade.result}`)
    .join("، ");
  const rate = closed.length ? Math.round((wins / closed.length) * 100) : 0;
  return `مغلقة ${closed.length}، الرابحة أو الجزئية ${wins} (${rate}%). آخر السجل: ${recent}`;
}
