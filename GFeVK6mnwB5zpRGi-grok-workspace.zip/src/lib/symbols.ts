export type SymbolKind = "metal" | "fx" | "energy";

export type WatchSymbol = {
  id: string;
  sq: string;
  yahoo: string;
  nameAr: string;
  unit: string;
  digits: number;
  kind: SymbolKind;
};

export const WATCH: WatchSymbol[] = [
  { id: "XAUUSD", sq: "XAU/USD", yahoo: "GC=F", nameAr: "الذهب", unit: "دولار للأونصة", digits: 2, kind: "metal" },
  { id: "XAGUSD", sq: "XAG/USD", yahoo: "SI=F", nameAr: "الفضة", unit: "دولار للأونصة", digits: 3, kind: "metal" },
  { id: "EURUSD", sq: "EUR/USD", yahoo: "EURUSD=X", nameAr: "اليورو / الدولار", unit: "", digits: 5, kind: "fx" },
  { id: "GBPUSD", sq: "GBP/USD", yahoo: "GBPUSD=X", nameAr: "الإسترليني / الدولار", unit: "", digits: 5, kind: "fx" },
  { id: "USDJPY", sq: "USD/JPY", yahoo: "USDJPY=X", nameAr: "الدولار / الين", unit: "", digits: 3, kind: "fx" },
  { id: "USDCHF", sq: "USD/CHF", yahoo: "USDCHF=X", nameAr: "الدولار / الفرنك", unit: "", digits: 5, kind: "fx" },
  { id: "AUDUSD", sq: "AUD/USD", yahoo: "AUDUSD=X", nameAr: "الأسترالي / الدولار", unit: "", digits: 5, kind: "fx" },
  { id: "USDCAD", sq: "USD/CAD", yahoo: "USDCAD=X", nameAr: "الدولار / الكندي", unit: "", digits: 5, kind: "fx" },
  { id: "NZDUSD", sq: "NZD/USD", yahoo: "NZDUSD=X", nameAr: "النيوزلندي / الدولار", unit: "", digits: 5, kind: "fx" },
  { id: "EURGBP", sq: "EUR/GBP", yahoo: "EURGBP=X", nameAr: "اليورو / الإسترليني", unit: "", digits: 5, kind: "fx" },
  { id: "USDTRY", sq: "USD/TRY", yahoo: "USDTRY=X", nameAr: "الدولار / الليرة التركية", unit: "", digits: 3, kind: "fx" },
  { id: "OILUSD", sq: "OIL/USD", yahoo: "CL=F", nameAr: "النفط", unit: "دولار للبرميل", digits: 2, kind: "energy" },
];

export const WATCH_BY_ID = Object.fromEntries(WATCH.map((item) => [item.id, item])) as Record<string, WatchSymbol>;

export const PHONE_DISPLAY = "0936745420";
export const PHONE_TEL = "+963936745420";
export const APP_VERSION = "1.0.0";
export const BRAND = "ZADAN FOREX TRADING";

const DETECT: { id: string; re: RegExp }[] = [
  { id: "XAUUSD", re: /ذهب|الذهب|gold|xau/i },
  { id: "XAGUSD", re: /فض[ةه]|الفضة|silver|xag/i },
  { id: "OILUSD", re: /نفط|النفط|oil|wti|خام/i },
  { id: "EURUSD", re: /يورو.?دولار|اليورو|eurusd|eur\/usd/i },
  { id: "GBPUSD", re: /إسترليني|استرليني|الباوند|gbpusd|gbp/i },
  { id: "USDJPY", re: /ين|usdjp|الين/i },
  { id: "USDCHF", re: /فرنك|usdchf/i },
  { id: "AUDUSD", re: /أسترالي|استرالي|audusd/i },
  { id: "USDCAD", re: /كندي|usdcad/i },
  { id: "NZDUSD", re: /نيوزلند|nzd/i },
  { id: "EURGBP", re: /يورو.?إسترليني|يورو.?استرليني|eurgbp/i },
  { id: "USDTRY", re: /ليرة|تركي|usdtry/i },
];

export function detectSymbol(text: string): string {
  for (const row of DETECT) {
    if (row.re.test(text)) return row.id;
  }
  return "XAUUSD";
}

export function fmtPrice(value: number, digits: number): string {
  return value.toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export function fmtPct(value: number | null): string {
  if (value == null || Number.isNaN(value)) return "—";
  const sign = value > 0 ? "+" : "";
  return `${sign}${value.toFixed(2)}%`;
}
