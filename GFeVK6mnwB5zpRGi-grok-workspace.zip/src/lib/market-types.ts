export type Candle = {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
};

export type Quote = {
  id: string;
  nameAr: string;
  unit: string;
  digits: number;
  kind: "metal" | "fx" | "energy";
  bid: number;
  ask: number;
  mid: number;
  spread: number;
  changePct: number | null;
  ts: number;
};

export type Board = {
  quotes: Quote[];
  fetchedAt: number;
  online: boolean;
};

export type Series = {
  id: string;
  candles: Candle[];
  fetchedAt: number;
  anchored: boolean;
  note: string;
};

export type CalEvent = {
  id: string;
  title: string;
  titleAr: string;
  country: string;
  countryAr: string;
  time: number;
  impact: "High" | "Medium" | "Low";
  forecast: string;
  previous: string;
  goldNote: string;
};

export type CalendarPayload = {
  events: CalEvent[];
  fetchedAt: number;
};

export type Side = "buy" | "sell" | "wait";
export type Lean = "buy" | "sell" | "flat";

export type SchoolNote = {
  name: string;
  note: string;
};

export type Signal = {
  symbol: string;
  side: Side;
  lean: Lean;
  score: number;
  maxScore: number;
  minScore: number;
  entryLow: number;
  entryHigh: number;
  sl: number;
  tp1: number;
  tp2: number;
  atr: number;
  rsi: number;
  z: number;
  session: string;
  sessionQuality: "high" | "mid" | "low";
  structure: string;
  reasons: string[];
  blockers: string[];
  schools: SchoolNote[];
  support: number | null;
  resistance: number | null;
  stamp: string;
};
