import { createServerFn } from "@tanstack/react-start";
import type { Board, CalEvent, CalendarPayload, Candle, Quote, Series } from "@/lib/market-types";
import { WATCH, WATCH_BY_ID } from "@/lib/symbols";

const UA = "Mozilla/5.0 (compatible; ZadanFX/1.0)";

type Cache<T> = { at: number; data: T };

let boardCache: Cache<Board> | null = null;
let changeCache: Cache<Record<string, number | null>> | null = null;
const seriesCache = new Map<string, Cache<Series>>();
let calendarCache: Cache<CalendarPayload> | null = null;

const TITLE_AR: Record<string, string> = {
  "Non-Farm Employment Change": "الوظائف غير الزراعية",
  "Nonfarm Payrolls": "الوظائف غير الزراعية",
  "Unemployment Rate": "معدل البطالة",
  "Average Hourly Earnings m/m": "متوسط الأجور بالساعة",
  "CPI m/m": "تضخم أسعار المستهلك شهرياً",
  "CPI y/y": "تضخم أسعار المستهلك سنوياً",
  "Core CPI m/m": "التضخم الأساسي شهرياً",
  "Core CPI y/y": "التضخم الأساسي سنوياً",
  "PPI m/m": "أسعار المنتجين شهرياً",
  "Core PPI m/m": "أسعار المنتجين الأساسية",
  "FOMC Statement": "بيان الفيدرالي الأمريكي",
  "Federal Funds Rate": "قرار الفائدة الأمريكية",
  "FOMC Press Conference": "المؤتمر الصحفي للفيدرالي",
  "FOMC Meeting Minutes": "محضر اجتماع الفيدرالي",
  "GDP q/q": "النمو الاقتصادي ربع السنوي",
  "Advance GDP q/q": "القراءة المتقدمة للنمو",
  "Retail Sales m/m": "مبيعات التجزئة",
  "Core Retail Sales m/m": "مبيعات التجزئة الأساسية",
  "ISM Manufacturing PMI": "مؤشر الصناعة الأمريكي",
  "ISM Services PMI": "مؤشر الخدمات الأمريكي",
  "ADP Non-Farm Employment Change": "وظائف القطاع الخاص",
  "Initial Jobless Claims": "طلبات إعانة البطالة",
  "Crude Oil Inventories": "مخزون النفط الأمريكي",
  "ECB Press Conference": "مؤتمر البنك المركزي الأوروبي",
  "Main Refinancing Rate": "فائدة البنك المركزي الأوروبي",
  "Monetary Policy Statement": "بيان السياسة النقدية",
  "Official Bank Rate": "فائدة بنك إنجلترا",
  "BOE Gov Bailey Speaks": "تصريح محافظ بنك إنجلترا",
  "BOJ Policy Rate": "فائدة بنك اليابان",
  "Unemployment Claims": "طلبات البطالة",
  "PCE Price Index m/m": "مؤشر إنفاق المستهلك",
  "Core PCE Price Index m/m": "مؤشر الإنفاق الأساسي",
  "CB Consumer Confidence": "ثقة المستهلك",
  "Flash Manufacturing PMI": "مؤشر الصناعة السريع",
  "Flash Services PMI": "مؤشر الخدمات السريع",
  "Trade Balance": "الميزان التجاري",
};

const COUNTRY_AR: Record<string, string> = {
  USD: "الدولار",
  EUR: "اليورو",
  GBP: "الإسترليني",
  JPY: "الين",
  CAD: "الدولار الكندي",
  AUD: "الدولار الأسترالي",
  NZD: "الدولار النيوزلندي",
  CHF: "الفرنك",
  CNY: "اليوان",
  All: "عالمي",
  OIL: "النفط",
};

function goldNote(title: string): string {
  const text = title.toLowerCase();
  if (/cpi|inflation|ppi|pce|price index/.test(text)) {
    return "ميل تاريخي: تضخم أعلى من المتوقع يقوّي الدولار غالباً ويضغط الذهب، والرقم الأضعف يميل لدعم الذهب. ليست قاعدة ثابتة.";
  }
  if (/non-farm|nonfarm|unemployment|jobless|adp|employment|payroll/.test(text)) {
    return "ميل تاريخي: وظائف أقوى تدعم الدولار وقد تضغط الذهب. مفاجأة سلبية بالتوظيف غالباً تدعم الذهب قبل أن تهدأ الحركة.";
  }
  if (/fomc|federal funds|powell|fed chair|interest rate|boe|ecb|boj|bank rate|refinancing/.test(text)) {
    return "ميل تاريخي: لهجة متشددة أو فائدة أعلى تضغط الذهب، ولهجة ميسرة تدعمه. التقلب يقفز مع الخبر نفسه، لذلك الخطة تكون قبله وبعده لا داخله.";
  }
  if (/gdp|retail sales|ism|pmi|consumer confidence/.test(text)) {
    return "ميل تاريخي: نشاط أقوى من المتوقع يدعم العملة المحلية. الذهب يتفاعل غالباً عبر قوة الدولار لا عبر الخبر بمعزل.";
  }
  if (/crude|oil|inventor/.test(text)) {
    return "مخزون النفط يحرّك الخام مباشرة، ويصل الذهب من باب توقعات التضخم. العلاقة ليست لحظية دائماً.";
  }
  return "راقبه إذا فاجأ السوق. الذهب يتحرك غالباً عكس مفاجآت قوة الدولار، مع استثناءات في أيام الذعر.";
}

function titleAr(title: string): string {
  return TITLE_AR[title] ?? title;
}

async function mapPool<T>(items: T[], limit: number, fn: (item: T) => Promise<void>): Promise<void> {
  let index = 0;
  async function worker() {
    while (index < items.length) {
      const current = items[index];
      index += 1;
      await fn(current);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => worker()));
}

async function fetchJson(url: string): Promise<unknown> {
  const response = await fetch(url, { headers: { "User-Agent": UA, Accept: "application/json" } });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}

function pickLive(payload: unknown): { bid: number; ask: number; ts: number } | null {
  if (!Array.isArray(payload) || payload.length === 0) return null;
  const row = payload[0] as { spreadProfilePrices?: { spreadProfile?: string; bid?: number; ask?: number }[]; ts?: number };
  const prices = row.spreadProfilePrices;
  if (!prices?.length) return null;
  const chosen = prices.find((item) => item.spreadProfile === "prime") ?? prices[0];
  const bid = Number(chosen.bid);
  const ask = Number(chosen.ask);
  if (!Number.isFinite(bid) || !Number.isFinite(ask) || ask <= 0 || bid <= 0) return null;
  return { bid, ask, ts: Number(row.ts) || Date.now() };
}

function parseYahoo(data: unknown): { changePct: number | null; candles: Candle[] } {
  const result = (data as { chart?: { result?: Array<Record<string, unknown>> } })?.chart?.result?.[0];
  if (!result) return { changePct: null, candles: [] };
  const meta = (result.meta ?? {}) as { previousClose?: number; chartPreviousClose?: number };
  const previous = Number(meta.previousClose ?? meta.chartPreviousClose);
  const timestamps = (result.timestamp as number[] | undefined) ?? [];
  const quote = ((result.indicators as { quote?: Array<Record<string, Array<number | null>>> })?.quote ?? [])[0];
  const candles: Candle[] = [];
  if (quote) {
    for (let i = 0; i < timestamps.length; i++) {
      const o = quote.open?.[i];
      const h = quote.high?.[i];
      const l = quote.low?.[i];
      const c = quote.close?.[i];
      if (typeof o === "number" && typeof h === "number" && typeof l === "number" && typeof c === "number") {
        candles.push({ t: timestamps[i] * 1000, o, h, l, c });
      }
    }
  }
  const last = candles.at(-1)?.c;
  const changePct = Number.isFinite(previous) && previous > 0 && last ? ((last - previous) / previous) * 100 : null;
  return { changePct, candles };
}

async function loadChanges(): Promise<Record<string, number | null>> {
  if (changeCache && Date.now() - changeCache.at < 180_000) return changeCache.data;
  const map: Record<string, number | null> = {};
  await mapPool(WATCH, 4, async (item) => {
    try {
      const data = await fetchJson(
        `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(item.yahoo)}?interval=1d&range=5d`,
      );
      map[item.id] = parseYahoo(data).changePct;
    } catch {
      map[item.id] = null;
    }
  });
  changeCache = { at: Date.now(), data: map };
  return map;
}

export async function loadBoard(): Promise<Board> {
  if (boardCache && Date.now() - boardCache.at < 8_000) return boardCache.data;
  const changesPromise = loadChanges();
  const lives = new Map<string, { bid: number; ask: number; ts: number }>();
  await mapPool(WATCH, 6, async (item) => {
    try {
      const data = await fetchJson(
        `https://forex-data-feed.swissquote.com/public-quotes/bboquotes/instrument/${item.sq}`,
      );
      const live = pickLive(data);
      if (live) lives.set(item.id, live);
    } catch {
      /* keep going so one symbol does not blank the board */
    }
  });
  const changes = await changesPromise;
  const quotes: Quote[] = [];
  for (const item of WATCH) {
    const live = lives.get(item.id);
    if (!live) continue;
    quotes.push({
      id: item.id,
      nameAr: item.nameAr,
      unit: item.unit,
      digits: item.digits,
      kind: item.kind,
      bid: live.bid,
      ask: live.ask,
      mid: (live.bid + live.ask) / 2,
      spread: live.ask - live.bid,
      changePct: changes[item.id] ?? null,
      ts: live.ts,
    });
  }
  const board: Board = { quotes, fetchedAt: Date.now(), online: quotes.length > 0 };
  if (quotes.length) boardCache = { at: Date.now(), data: board };
  return board;
}

export async function loadSeries(id: string): Promise<Series> {
  const symbol = WATCH_BY_ID[id];
  if (!symbol) throw new Error("رمز غير معروف");
  const cached = seriesCache.get(id);
  if (cached && Date.now() - cached.at < 60_000) return cached.data;
  const [liveData, yahooData] = await Promise.all([
    fetchJson(`https://forex-data-feed.swissquote.com/public-quotes/bboquotes/instrument/${symbol.sq}`),
    fetchJson(
      `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol.yahoo)}?interval=5m&range=1d`,
    ).catch(() => null),
  ]);
  const live = pickLive(liveData);
  const parsed = yahooData ? parseYahoo(yahooData) : { changePct: null, candles: [] as Candle[] };
  let candles = parsed.candles;
  let anchored = false;
  let note = "شموع ٥ دقائق.";
  if (live && candles.length) {
    const last = candles[candles.length - 1].c;
    const mid = (live.bid + live.ask) / 2;
    const shift = mid - last;
    if (last > 0 && Math.abs(shift) / last < 0.03) {
      candles = candles.map((candle) => ({
        t: candle.t,
        o: candle.o + shift,
        h: candle.h + shift,
        l: candle.l + shift,
        c: candle.c + shift,
      }));
      anchored = true;
      note = "شموع ٥ دقائق مُحاذاة مع السعر الفوري الحالي.";
    } else {
      note = "الشموع من العقد المرجعي، والفرق عن الفوري أكبر من المعتاد.";
    }
  }
  const series: Series = { id, candles, fetchedAt: Date.now(), anchored, note };
  if (candles.length) seriesCache.set(id, { at: Date.now(), data: series });
  return series;
}

export async function loadCalendar(): Promise<CalendarPayload> {
  if (calendarCache && Date.now() - calendarCache.at < 300_000) return calendarCache.data;
  const raw = (await fetchJson("https://nfs.faireconomy.media/ff_calendar_thisweek.json")) as Array<{
    title?: string;
    country?: string;
    date?: string;
    impact?: string;
    forecast?: string;
    previous?: string;
  }>;
  const now = Date.now();
  const events: CalEvent[] = [];
  for (const row of raw) {
    const impact = row.impact === "High" || row.impact === "Medium" || row.impact === "Low" ? row.impact : "Low";
    if (impact === "Low") continue;
    const country = row.country || "";
    const relevant = ["USD", "EUR", "GBP", "JPY", "CAD", "AUD", "CHF", "NZD", "CNY"].includes(country);
    if (!relevant) continue;
    if (impact === "Medium" && country !== "USD") continue;
    const time = row.date ? new Date(row.date).getTime() : Number.NaN;
    if (!Number.isFinite(time)) continue;
    if (time < now - 6 * 60 * 60 * 1000 || time > now + 72 * 60 * 60 * 1000) continue;
    const title = row.title || "حدث";
    events.push({
      id: `${country}-${time}-${title}`,
      title,
      titleAr: titleAr(title),
      country,
      countryAr: COUNTRY_AR[country] ?? country,
      time,
      impact,
      forecast: row.forecast || "—",
      previous: row.previous || "—",
      goldNote: goldNote(title),
    });
  }
  events.sort((a, b) => a.time - b.time);
  const payload: CalendarPayload = { events: events.slice(0, 30), fetchedAt: Date.now() };
  calendarCache = { at: Date.now(), data: payload };
  return payload;
}

export const getBoard = createServerFn({ method: "GET" }).handler(async () => {
  try {
    return await loadBoard();
  } catch {
    return { quotes: [], fetchedAt: Date.now(), online: false } satisfies Board;
  }
});

export const getSeries = createServerFn({ method: "GET" })
  .validator((input: unknown) => {
    const id = typeof input === "string" ? input : (input as { id?: string } | null)?.id;
    if (!id || !WATCH_BY_ID[id]) throw new Error("رمز غير معروف");
    return { id };
  })
  .handler(async ({ data }) => {
    try {
      return await loadSeries(data.id);
    } catch {
      return { id: data.id, candles: [], fetchedAt: Date.now(), anchored: false, note: "تعذر تحميل الشموع." } satisfies Series;
    }
  });

export const getCalendar = createServerFn({ method: "GET" }).handler(async () => {
  try {
    return await loadCalendar();
  } catch {
    return { events: [], fetchedAt: Date.now() } satisfies CalendarPayload;
  }
});
