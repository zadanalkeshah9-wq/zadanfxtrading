import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as createServerFn } from "./ssr.mjs";
import { c as fmtPct, i as PHONE_TEL, l as fmtPrice, n as BRAND, o as WATCH_BY_ID, r as PHONE_DISPLAY, s as detectSymbol, t as APP_VERSION } from "./symbols-B3ucanza.mjs";
import { a as getSeries, i as getCalendar, l as minScoreFromJournal, n as createSsrRpc, r as getBoard, t as analyze, u as nextHighImpact } from "./market-PmevV4bE.mjs";
import { a as MessageSquareText, i as Newspaper, n as Share2, o as Crosshair, r as Phone, s as ChartCandlestick } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DkSROgny.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CallOverlay({ status, transcript, error, onHangup }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40 flex flex-col bg-bg px-6 pb-8 pt-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm tracking-widest text-gold",
				children: "مكالمة غرفة التداول"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col items-center justify-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative grid size-52 place-items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 rounded-full border border-gold/40" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-4 rounded-full border border-gold/70" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/zadan-logo.jpg",
								alt: "",
								className: "size-36 object-contain"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-6 text-2xl font-bold",
						children: "ZADAN FOREX TRADING"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-gold",
						children: status
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-h-36 overflow-auto text-center text-sm leading-6 text-muted",
						children: error || transcript || "احكِ عن الذهب أو عن الزوج يلي بدك يا. مثلاً: أعطيني صفقة عالذهب."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onHangup,
				className: "mx-auto rounded-full bg-down px-8 py-3 font-semibold text-fg",
				children: "إنهاء المكالمة"
			})
		]
	});
}
function RichText({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col gap-1.5 text-sm leading-6",
		children: text.split("\n").map((line, index) => {
			if (!line.trim()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1" }, index);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: inline(line) }, index);
		})
	});
}
function inline(line) {
	return line.split(/(\*\*[^*]+\*\*)/g).map((part, index) => {
		if (part.startsWith("**") && part.endsWith("**")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
			className: "font-semibold text-gold-2",
			children: part.slice(2, -2)
		}, index);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: part }, index);
	});
}
function ChatView({ messages, draft, listening, onDraft, onSend, onMic, onSpeak, onClear, onPrompt, speakOn, onToggleSpeak }) {
	const endRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		endRef.current?.scrollIntoView({ block: "end" });
	}, [messages]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "room flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "chat-watermark flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto px-4 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onToggleSpeak,
						className: "text-xs text-gold",
						children: speakOn ? "الرد الصوتي شغّال" : "تشغيل الرد الصوتي"
					}), messages.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClear,
						className: "text-xs text-muted",
						children: "مسح"
					}) : null]
				}),
				messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 rounded-lg border border-line bg-bg/80 px-4 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: "اسأل عن الذهب أو أي زوج."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm leading-6 text-muted",
							children: "صفقة، دعم ومقاومة، خبر، أو مقارنة بين المدارس. الجواب يقرأ السعر الحالي قبل ما يكتب."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-col gap-2",
							children: [
								"أعطني صفقة على الذهب",
								"وين دعم ومقاومة الذهب؟",
								"حلّل اليورو دولار",
								"شو أخبار اليوم بتأثر عالذهب؟"
							].map((prompt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onPrompt(prompt),
								className: "rounded-lg border border-line bg-surface px-3 py-2 text-start text-sm",
								children: prompt
							}, prompt))
						})
					]
				}) : messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: `max-w-[92%] rounded-lg px-3 py-2 ${message.role === "user" ? "self-start bg-gold text-bg" : "self-end border border-line bg-bg/85"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, { text: message.content }),
						message.pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-gold",
							children: "يكمل الشرح من الشارت…"
						}) : null,
						message.role === "assistant" && !message.pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onSpeak(message.content),
							className: "mt-2 text-xs font-semibold text-gold",
							children: "اسمع الجواب"
						}) : null
					]
				}, message.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: endRef })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex items-end gap-2 border-t border-line bg-bg px-3 py-2",
			onSubmit: (event) => {
				event.preventDefault();
				onSend();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onMic,
					className: `grid size-11 shrink-0 place-items-center rounded-full border ${listening ? "border-gold bg-gold text-bg" : "border-line"}`,
					"aria-label": "رسالة صوتية",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicIcon, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: draft,
					onChange: (event) => onDraft(event.target.value),
					rows: 1,
					placeholder: "اكتب سؤالك عن السوق",
					className: "max-h-28 min-h-11 flex-1 resize-none rounded-lg border border-line bg-surface px-3 py-2 outline-none",
					onKeyDown: (event) => {
						if (event.key === "Enter" && !event.shiftKey) {
							event.preventDefault();
							onSend();
						}
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "grid size-11 shrink-0 place-items-center rounded-full bg-gold text-bg",
					"aria-label": "إرسال",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SendIcon, {})
				})
			]
		})]
	});
}
function MicIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className: "size-5",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "9",
			y: "3",
			width: "6",
			height: "11",
			rx: "3"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6 11a6 6 0 0 0 12 0M12 17v4" })]
	});
}
function SendIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: "size-5",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 12h14M13 6l6 6-6 6" })
	});
}
function CandleChart({ candles }) {
	const view = candles.slice(-56);
	if (view.length < 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-10 text-center text-sm text-muted",
		children: "بانتظار الشموع من السوق…"
	});
	const high = Math.max(...view.map((candle) => candle.h));
	const low = Math.min(...view.map((candle) => candle.l));
	const pad = (high - low) * .08 || high * .001;
	const top = high + pad;
	const bottom = low - pad;
	const width = 100;
	const height = 46;
	const slot = width / view.length;
	const y = (price) => (top - price) / (top - bottom) * height;
	const last = view[view.length - 1];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${width} ${height}`,
		className: "h-48 w-full",
		role: "img",
		"aria-label": "مخطط الشموع",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "0",
			x2: width,
			y1: y(last.c),
			y2: y(last.c),
			stroke: "var(--color-gold)",
			strokeWidth: "0.15",
			strokeDasharray: "0.8 0.6"
		}), view.map((candle, index) => {
			const color = candle.c >= candle.o ? "var(--color-up)" : "var(--color-down)";
			const x = index * slot + slot / 2;
			const bodyTop = y(Math.max(candle.o, candle.c));
			const bodyBot = y(Math.min(candle.o, candle.c));
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: x,
				x2: x,
				y1: y(candle.h),
				y2: y(candle.l),
				stroke: color,
				strokeWidth: "0.28"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: x - slot * .26,
				y: bodyTop,
				width: Math.max(slot * .52, .35),
				height: Math.max(bodyBot - bodyTop, .35),
				fill: color
			})] }, candle.t);
		})]
	});
}
function MarketView({ quotes, selected, series, onSelect }) {
	const focus = quotes.find((quote) => quote.id === selected) ?? quotes[0];
	if (!focus) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-5 py-16 text-center text-muted",
		children: "يتم الاتصال بالسوق…"
	});
	const up = (focus.changePct ?? 0) >= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 px-4 pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border-b border-line pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: focus.nameAr
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-4xl font-bold tabular-nums tracking-tight text-gold-2",
							children: fmtPrice(focus.mid, focus.digits)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: focus.unit || focus.id
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-lg font-semibold tabular-nums ${up ? "text-up" : "text-down"}`,
						children: fmtPct(focus.changePct)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-3 gap-2 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "شراء",
							value: fmtPrice(focus.bid, focus.digits)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "بيع",
							value: fmtPrice(focus.ask, focus.digits)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "السبريد",
							value: fmtPrice(focus.spread, focus.digits)
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-base font-semibold",
					children: "الشارت"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: series?.note ?? "تُحدَّث الشموع كل دقيقة"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CandleChart, { candles: series?.candles ?? [] })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-base font-semibold",
				children: "الشريط"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-line border-y border-line",
				children: quotes.map((quote) => {
					const positive = (quote.changePct ?? 0) >= 0;
					const active = quote.id === focus.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onSelect(quote.id),
						className: `flex w-full items-center gap-3 py-3 text-start ${active ? "text-gold-2" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate font-medium",
									children: quote.nameAr
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: quote.id
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums font-semibold",
								children: fmtPrice(quote.mid, quote.digits)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `w-16 text-end text-sm tabular-nums ${positive ? "text-up" : "text-down"}`,
								children: fmtPct(quote.changePct)
							})
						]
					}) }, quote.id);
				})
			})] })
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-surface px-2 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm font-semibold tabular-nums",
			children: value
		})]
	});
}
function whenLabel(time, now) {
	const diff = time - now;
	const mins = Math.round(diff / 6e4);
	if (mins > 0 && mins < 180) return `بعد ${mins} د`;
	if (mins < 0 && mins > -180) return `منذ ${Math.abs(mins)} د`;
	return new Intl.DateTimeFormat("ar-SY", {
		timeZone: "Asia/Damascus",
		weekday: "short",
		hour: "2-digit",
		minute: "2-digit"
	}).format(time);
}
function NewsView({ events, now, alertsOn, onToggleAlerts, onEnablePush }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4 px-4 pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-line bg-surface px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold",
						children: "رادار الأخبار"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-6 text-muted",
						children: "يراقب الأخبار عالية التأثير على الدولار والذهب، ويقدّر الميل التاريخي قبل صدورها. التنبيه يطلع والتطبيق مفتوح أو مثبّت والإشعارات مفعّلة."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onToggleAlerts,
							className: "rounded-lg bg-gold px-3 py-3 text-sm font-semibold text-bg",
							children: alertsOn ? "التنبيهات شغالة" : "تشغيل التنبيهات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onEnablePush,
							className: "rounded-lg border border-line px-3 py-3 text-sm font-semibold",
							children: "إشعار الهاتف"
						})]
					})
				]
			}),
			events.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-8 text-center text-sm text-muted",
				children: "التقويم غير متاح حالياً. أعد المحاولة بعد لحظات."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "relative border-s border-line ps-4",
				children: events.map((event) => {
					const soon = event.time - now < 18e5 && event.time > now;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "mb-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute -start-1.5 mt-1.5 size-3 rounded-full ${event.impact === "High" ? "bg-gold" : "bg-line"}` }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									whenLabel(event.time, now),
									" · ",
									event.countryAr,
									" · ",
									event.impact === "High" ? "تأثير عالي" : "تأثير متوسط",
									soon ? " · قريب" : ""
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 font-semibold",
								children: event.titleAr
							}),
							event.titleAr !== event.title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: event.title
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm tabular-nums text-muted",
								children: [
									"السابق ",
									event.previous,
									" · المتوقع ",
									event.forecast
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-6",
								children: event.goldNote
							})
						]
					}, event.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-5 text-muted",
				children: "الميل التاريخي ليس توقعاً مضموناً. الخبر يفاجئ، والخطة تكون حدّين: ردة فوق الرقم وردة تحته."
			})
		]
	});
}
function SignalView({ quote, signal, journal, onExplain, onTrack }) {
	if (!quote || !signal) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-5 py-16 text-center text-muted",
		children: "تُبنى القراءة بعد وصول الشموع…"
	});
	const px = (value) => fmtPrice(value, quote.digits);
	const closed = journal.filter((trade) => trade.result !== "open");
	const wins = closed.filter((trade) => trade.result === "win" || trade.result === "partial").length;
	const rate = closed.length ? Math.round(wins / closed.length * 100) : null;
	const tone = signal.side === "buy" ? "text-up" : signal.side === "sell" ? "text-down" : "text-gold";
	const title = signal.side === "buy" ? "شراء" : signal.side === "sell" ? "بيع" : "انتظار";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 px-4 pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-line bg-surface px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: WATCH_BY_ID[quote.id]?.nameAr ?? quote.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: `text-4xl font-extrabold ${tone}`,
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-end text-sm text-muted",
							children: [
								"توافق ",
								signal.score,
								"/",
								signal.maxScore,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 block",
									children: ["الحد الحالي ", signal.minScore]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex gap-1",
						children: Array.from({ length: signal.maxScore }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 flex-1 rounded-full ${index < signal.score ? "bg-gold" : "bg-line"}` }, index))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-6 text-muted",
						children: signal.structure
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Level, {
						label: "منطقة الدخول",
						value: `${px(signal.entryLow)} – ${px(signal.entryHigh)}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Level, {
						label: "وقف الخسارة",
						value: px(signal.sl)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Level, {
						label: "الهدف الأول",
						value: px(signal.tp1)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Level, {
						label: "الهدف الثاني",
						value: px(signal.tp2)
					})
				]
			}),
			signal.side === "wait" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-6 text-muted",
				children: "الخطة أعلاه مشروطة وليست أمراً بالدخول. المحرك يرفض الصفقة الضعيفة حتى تبقى الاحتمالات لصالحك، بدون أي ضمان."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onExplain,
					className: "rounded-lg bg-gold px-3 py-3 font-semibold text-bg",
					children: "اشرح الصفقة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onTrack,
					className: "rounded-lg border border-gold px-3 py-3 font-semibold text-gold",
					children: "راقبها في الدفتر"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 font-semibold",
				children: "المدارس"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: signal.schools.map((school) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg border border-line px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-gold",
						children: school.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-6 text-fg/90",
						children: school.note
					})]
				}, school.name))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface-2 px-3 py-3 text-sm leading-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "دفتر التعلم على جهازك"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-muted",
						children: closed.length ? `${wins} من ${closed.length} انتهت ربحاً أو جزئياً (${rate}%). إذا ضعفت النتائج يرفع المحرك حد الدخول تلقائياً.` : "لما تنراقب صفقة ويوصل السعر للهدف أو الوقف، يتعلم المحرك من النتيجة ويصير أكثر انتقاءً."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 divide-y divide-line",
						children: journal.slice(0, 6).map((trade) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between py-2 tabular-nums",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								trade.nameAr,
								" · ",
								trade.side === "buy" ? "شراء" : "بيع"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: trade.result === "loss" ? "text-down" : trade.result === "open" ? "text-gold" : "text-up",
								children: trade.result === "win" ? "ربح" : trade.result === "loss" ? "خسارة" : trade.result === "partial" ? "جزئي" : "مفتوحة"
							})]
						}, trade.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-5 text-muted",
				children: "تحليل تعليمي من قراءة الشارت والأخبار. لا أحد يستطيع ضمان صفقة بلا خسارة، والتطبيق يقول «انتظار» عندما تكون الجودة ضعيفة."
			})
		]
	});
}
function Level({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-semibold tabular-nums",
			children: value
		})]
	});
}
function clip(text, max) {
	const clean = text.replace(/\s+/g, " ").trim();
	return clean.length > max ? `${clean.slice(0, max)}…` : clean;
}
var askAnalyst = createServerFn({ method: "POST" }).validator((input) => {
	const body = input;
	if (!body || typeof body.question !== "string" || body.question.trim().length < 1) throw new Error("اكتب سؤالاً");
	const history = [];
	if (Array.isArray(body.history)) for (const turn of body.history.slice(-8)) {
		const row = turn;
		if ((row.role === "user" || row.role === "assistant") && typeof row.content === "string") history.push({
			role: row.role,
			content: clip(row.content, 1200)
		});
	}
	const journal = typeof body.journal === "string" ? clip(body.journal, 800) : "";
	const minScore = body.minScore === 6 ? 6 : 5;
	return {
		question: clip(body.question, 2e3),
		history,
		journal,
		minScore
	};
}).handler(createSsrRpc("f935ff5a01f4a7105bdda1cdf6770454c5c049b2a8f235ef4cf93438679500f6"));
var useDesk = create()(persist((set) => ({
	messages: [],
	journal: [],
	alertsOn: true,
	speakOn: true,
	seenAlerts: [],
	bannerDismissed: false,
	addMessage: (message) => set((state) => ({ messages: [...state.messages, message].slice(-40) })),
	patchMessage: (id, patch) => set((state) => ({ messages: state.messages.map((message) => message.id === id ? {
		...message,
		...patch
	} : message) })),
	clearChat: () => set({ messages: [] }),
	trackTrade: (trade) => set((state) => {
		if (state.journal.some((item) => item.id === trade.id || item.symbol === trade.symbol && item.result === "open")) return state;
		return { journal: [trade, ...state.journal].slice(0, 30) };
	}),
	review: (quotes) => set((state) => {
		let changed = false;
		const journal = state.journal.map((trade) => {
			if (trade.result === "win" || trade.result === "loss" || trade.closedAt) return trade;
			const quote = quotes.find((item) => item.id === trade.symbol);
			if (!quote) return trade;
			const hit = trade.side === "buy" ? quote.bid : quote.ask;
			let next = trade;
			if (!trade.tp1Hit && (trade.side === "buy" && hit >= trade.tp1 || trade.side === "sell" && hit <= trade.tp1)) next = {
				...trade,
				tp1Hit: true,
				result: "partial"
			};
			if (trade.side === "buy" && hit >= trade.tp2 || trade.side === "sell" && hit <= trade.tp2) {
				changed = true;
				return {
					...next,
					result: "win",
					closedAt: Date.now()
				};
			}
			const stopped = trade.side === "buy" ? hit <= trade.sl : hit >= trade.sl;
			if (stopped && !next.tp1Hit) {
				changed = true;
				return {
					...next,
					result: "loss",
					closedAt: Date.now()
				};
			}
			if (stopped && next.tp1Hit) {
				changed = true;
				return {
					...next,
					result: "partial",
					closedAt: Date.now()
				};
			}
			if (next !== trade) changed = true;
			return next;
		});
		return changed ? { journal } : state;
	}),
	setAlerts: (alertsOn) => set({ alertsOn }),
	setSpeak: (speakOn) => set({ speakOn }),
	markAlert: (id) => set((state) => ({ seenAlerts: state.seenAlerts.includes(id) ? state.seenAlerts : [...state.seenAlerts, id].slice(-40) })),
	dismissBanner: () => set({ bannerDismissed: true })
}), {
	name: "zadan-fx-desk",
	skipHydration: true
}));
var DISCLAIMER = "هذا تحليل تعليمي وليس توصية ملزمة. الخسارة جزء من السوق، ولا توجد صفقة مضمونة.";
function isPriceQuestion(text) {
	const asksPrice = /سعر|كم |بكام|بكم|quote|price/i.test(text);
	const asksPlan = /صفقة|تحليل|دخول|وقف|هدف|شراء|بيع|موج|خبر|لين|لماذا|ليش|اشرح|هل/i.test(text);
	return asksPrice && !asksPlan;
}
function sideLabel(signal) {
	if (signal.side === "buy") return "شراء";
	if (signal.side === "sell") return "بيع";
	return "انتظار";
}
function formatSignalReply(quote, signal, events) {
	const name = WATCH_BY_ID[quote.id]?.nameAr ?? quote.id;
	const px = (value) => fmtPrice(value, quote.digits);
	const upcoming = events.find((event) => event.impact === "High" && event.time > Date.now());
	const lines = [
		`${name} الآن: شراء ${px(quote.bid)} / بيع ${px(quote.ask)} · اليوم ${fmtPct(quote.changePct)}`,
		`القرار: ${sideLabel(signal)} · التوافق ${signal.score} من ${signal.maxScore} (المطلوب ${signal.minScore})`,
		`الميل اللحظي: ${signal.lean === "buy" ? "صاعد" : signal.lean === "sell" ? "هابط" : "محايد"} · ${signal.session}`
	];
	if (signal.side === "wait") {
		lines.push("ما في صفقة بجودة كافية هلق. الدخول بالقوة هنا يرفع احتمال الخسارة.");
		if (signal.lean === "flat") lines.push("الاتجاه غير واضح. انتظر كسراً مؤكداً للقمة أو للقاع قبل أي دخول.");
		else if (signal.lean === "sell") lines.push(`خطة مشروطة للبيع إذا ثبت الرفض: الدخول ${px(signal.entryLow)} – ${px(signal.entryHigh)}. الوقف ${px(signal.sl)}. الهدف الأول ${px(signal.tp1)} والثاني ${px(signal.tp2)}.`);
		else lines.push(`خطة مشروطة للشراء إذا ثبت الارتداد: الدخول ${px(signal.entryLow)} – ${px(signal.entryHigh)}. الوقف ${px(signal.sl)}. الهدف الأول ${px(signal.tp1)} والثاني ${px(signal.tp2)}.`);
	} else {
		lines.push(`منطقة الدخول: ${px(signal.entryLow)} – ${px(signal.entryHigh)}`);
		lines.push(`وقف الخسارة: ${px(signal.sl)}`);
		lines.push(`جني الأرباح: ${px(signal.tp1)} ثم ${px(signal.tp2)}`);
		lines.push(`الإلغاء: إغلاق شمعة ٥ دقائق خلف الوقف، أو تغيّر البنية المذكورة.`);
	}
	if (signal.support != null || signal.resistance != null) lines.push(`دعم ${signal.support != null ? px(signal.support) : "—"} · مقاومة ${signal.resistance != null ? px(signal.resistance) : "—"}`);
	if (signal.reasons.length) lines.push(`ما يدعم الفكرة: ${signal.reasons.slice(0, 3).join("، ")}.`);
	if (signal.blockers.length) lines.push(`ما يمنع الثقة: ${signal.blockers.slice(0, 3).join("، ")}.`);
	lines.push(...signal.schools.map((school) => `${school.name}: ${school.note}`));
	if (upcoming) lines.push(`قبل الخبر: ${upcoming.titleAr} (${upcoming.countryAr}). ${upcoming.goldNote}`);
	lines.push(DISCLAIMER);
	return lines.join("\n");
}
function formatPriceReply(quote) {
	return [
		`${quote.nameAr}: سعر الشراء ${fmtPrice(quote.bid, quote.digits)} وسعر البيع ${fmtPrice(quote.ask, quote.digits)}.`,
		`السبريد ${fmtPrice(quote.spread, quote.digits)}${quote.unit ? ` · ${quote.unit}` : ""}.`,
		`تغير اليوم ${fmtPct(quote.changePct)}.`,
		"الرقم لحظي من مزود الأسعار طالما الاتصال شغّال."
	].join("\n");
}
function journalSummary(trades) {
	if (!trades.length) return "";
	const closed = trades.filter((trade) => trade.result === "win" || trade.result === "loss" || trade.result === "partial");
	const wins = closed.filter((trade) => trade.result === "win" || trade.result === "partial").length;
	const recent = trades.slice(0, 5).map((trade) => `${trade.symbol} ${trade.side} ${trade.result}`).join("، ");
	const rate = closed.length ? Math.round(wins / closed.length * 100) : 0;
	return `مغلقة ${closed.length}، الرابحة أو الجزئية ${wins} (${rate}%). آخر السجل: ${recent}`;
}
function uid() {
	return crypto.randomUUID();
}
function speakArabic(text) {
	return new Promise((resolve) => {
		if (typeof window === "undefined" || !window.speechSynthesis) {
			resolve();
			return;
		}
		window.speechSynthesis.cancel();
		const utter = new SpeechSynthesisUtterance(text.replace(/[*#]/g, " ").slice(0, 650));
		utter.lang = "ar-SA";
		utter.rate = 1;
		const voice = window.speechSynthesis.getVoices().find((item) => item.lang.toLowerCase().startsWith("ar"));
		if (voice) utter.voice = voice;
		utter.onend = () => resolve();
		utter.onerror = () => resolve();
		window.speechSynthesis.speak(utter);
	});
}
function buildSignal(quote, series, events, minScore) {
	if (!quote || !series || series.candles.length < 20) return null;
	return analyze({
		quote,
		candles: series.candles,
		nextHigh: nextHighImpact(events),
		minScore
	});
}
function ZadanApp() {
	const [entered, setEntered] = (0, import_react.useState)(false);
	const [tab, setTab] = (0, import_react.useState)("market");
	const [selected, setSelected] = (0, import_react.useState)("XAUUSD");
	const [board, setBoard] = (0, import_react.useState)(null);
	const [seriesMap, setSeriesMap] = (0, import_react.useState)({});
	const [events, setEvents] = (0, import_react.useState)([]);
	const [offline, setOffline] = (0, import_react.useState)(false);
	const [clock, setClock] = (0, import_react.useState)("");
	const [now, setNow] = (0, import_react.useState)(0);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [listening, setListening] = (0, import_react.useState)(false);
	const [toast, setToast] = (0, import_react.useState)("");
	const [sheet, setSheet] = (0, import_react.useState)(null);
	const [callOpen, setCallOpen] = (0, import_react.useState)(false);
	const [callStatus, setCallStatus] = (0, import_react.useState)("يستمع");
	const [callText, setCallText] = (0, import_react.useState)("");
	const [callError, setCallError] = (0, import_react.useState)("");
	const [installEvent, setInstallEvent] = (0, import_react.useState)(null);
	const desk = useDesk();
	const callAlive = (0, import_react.useRef)(false);
	const busy = (0, import_react.useRef)(false);
	const boardRef = (0, import_react.useRef)(null);
	const seriesRef = (0, import_react.useRef)({});
	const eventsRef = (0, import_react.useRef)([]);
	boardRef.current = board;
	seriesRef.current = seriesMap;
	eventsRef.current = events;
	(0, import_react.useEffect)(() => {
		useDesk.persist.rehydrate();
		const onPrompt = (event) => {
			event.preventDefault();
			setInstallEvent(event);
		};
		window.addEventListener("beforeinstallprompt", onPrompt);
		const clockId = window.setInterval(() => {
			const current = /* @__PURE__ */ new Date();
			setNow(current.getTime());
			setClock(new Intl.DateTimeFormat("ar-SY", {
				timeZone: "Asia/Damascus",
				hour: "2-digit",
				minute: "2-digit",
				second: "2-digit"
			}).format(current));
		}, 1e3);
		return () => {
			window.removeEventListener("beforeinstallprompt", onPrompt);
			window.clearInterval(clockId);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		let stop = false;
		async function pullBoard() {
			try {
				const next = await getBoard();
				if (stop) return;
				setBoard(next);
				setOffline(!next.online);
				if (next.quotes.length) useDesk.getState().review(next.quotes);
			} catch {
				if (!stop) setOffline(true);
			}
		}
		async function pullCalendar() {
			try {
				const next = await getCalendar();
				if (!stop) setEvents(next.events);
			} catch {}
		}
		pullBoard();
		pullCalendar();
		const boardId = window.setInterval(() => void pullBoard(), 1e4);
		const calendarId = window.setInterval(() => void pullCalendar(), 3e5);
		return () => {
			stop = true;
			window.clearInterval(boardId);
			window.clearInterval(calendarId);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const ids = Array.from(/* @__PURE__ */ new Set(["XAUUSD", selected]));
		let stop = false;
		async function pull(id) {
			try {
				const next = await getSeries({ data: { id } });
				if (!stop && next.candles.length) setSeriesMap((current) => ({
					...current,
					[id]: next
				}));
			} catch {}
		}
		for (const id of ids) pull(id);
		const timer = window.setInterval(() => {
			for (const id of ids) pull(id);
		}, 45e3);
		return () => {
			stop = true;
			window.clearInterval(timer);
		};
	}, [selected]);
	const minScore = minScoreFromJournal(desk.journal.map((trade) => trade.result));
	const quote = board?.quotes.find((item) => item.id === selected);
	const signal = (0, import_react.useMemo)(() => buildSignal(quote, seriesMap[selected], events, minScore), [
		quote,
		seriesMap,
		selected,
		events,
		minScore
	]);
	const goldQuote = board?.quotes.find((item) => item.id === "XAUUSD");
	const goldSignal = (0, import_react.useMemo)(() => buildSignal(goldQuote, seriesMap.XAUUSD, events, minScore), [
		goldQuote,
		seriesMap,
		events,
		minScore
	]);
	(0, import_react.useEffect)(() => {
		const state = useDesk.getState();
		if (!state.alertsOn || !goldSignal || goldSignal.side === "wait") return;
		if (state.seenAlerts.includes(goldSignal.stamp)) return;
		state.markAlert(goldSignal.stamp);
		const text = goldSignal.side === "buy" ? "فرصة شراء على الذهب. افتح تبويب الصفقة." : "فرصة بيع على الذهب. افتح تبويب الصفقة.";
		setToast(text);
		if (typeof Notification !== "undefined" && Notification.permission === "granted") new Notification(BRAND, {
			body: text,
			icon: "/zadan-logo.jpg"
		});
		if (goldQuote && (goldSignal.side === "buy" || goldSignal.side === "sell")) state.trackTrade({
			id: goldSignal.stamp,
			symbol: "XAUUSD",
			nameAr: "الذهب",
			side: goldSignal.side,
			entryLow: goldSignal.entryLow,
			entryHigh: goldSignal.entryHigh,
			sl: goldSignal.sl,
			tp1: goldSignal.tp1,
			tp2: goldSignal.tp2,
			openedAt: Date.now(),
			tp1Hit: false,
			result: "open"
		});
	}, [goldQuote, goldSignal]);
	(0, import_react.useEffect)(() => {
		const state = useDesk.getState();
		if (!state.alertsOn) return;
		const soon = events.find((event) => event.impact === "High" && event.time > Date.now() && event.time - Date.now() < 12e5);
		if (!soon || state.seenAlerts.includes(soon.id)) return;
		state.markAlert(soon.id);
		const text = `خبر قريب قد يحرّك الذهب: ${soon.titleAr}`;
		setToast(text);
		if (typeof Notification !== "undefined" && Notification.permission === "granted") new Notification(BRAND, {
			body: text,
			icon: "/zadan-logo.jpg"
		});
	}, [events]);
	(0, import_react.useEffect)(() => {
		if (!toast) return;
		const timer = window.setTimeout(() => setToast(""), 6e3);
		return () => window.clearTimeout(timer);
	}, [toast]);
	async function answerQuestion(question, voice) {
		const clean = question.trim();
		if (!clean) return "";
		const userId = uid();
		desk.addMessage({
			id: userId,
			role: "user",
			content: clean
		});
		const focus = detectSymbol(clean);
		const liveQuote = boardRef.current?.quotes.find((item) => item.id === focus);
		const liveSeries = seriesRef.current[focus];
		const liveEvents = eventsRef.current;
		const liveMin = minScoreFromJournal(useDesk.getState().journal.map((trade) => trade.result));
		const liveSignal = buildSignal(liveQuote, liveSeries, liveEvents, liveMin);
		let local = "أقرأ السعر والشارت الآن.";
		if (liveQuote && isPriceQuestion(clean)) local = formatPriceReply(liveQuote);
		else if (liveQuote && liveSignal) local = formatSignalReply(liveQuote, liveSignal, liveEvents);
		else if (liveQuote) local = `${formatPriceReply(liveQuote)}\nالشموع لم تكتمل بعد، والسعر نفسه محدّث.`;
		const botId = uid();
		const priceOnly = Boolean(liveQuote && isPriceQuestion(clean));
		desk.addMessage({
			id: botId,
			role: "assistant",
			content: local,
			pending: !priceOnly
		});
		if (priceOnly) {
			if (voice || useDesk.getState().speakOn) speakArabic(local);
			return local;
		}
		const history = useDesk.getState().messages.filter((message) => message.id !== botId && message.id !== userId).slice(-8).map((message) => ({
			role: message.role,
			content: message.content
		}));
		try {
			const result = await askAnalyst({ data: {
				question: clean,
				history,
				journal: journalSummary(useDesk.getState().journal),
				minScore: liveMin
			} });
			const finalText = result.ok ? `${local}\n\n${result.text}` : `${local}\n\n${result.error}`;
			desk.patchMessage(botId, {
				content: finalText,
				pending: false
			});
			if (voice || useDesk.getState().speakOn) speakArabic(result.ok ? result.text : local);
			return result.ok ? result.text : local;
		} catch {
			const finalText = `${local}\n\nتعذر إكمال الشرح الموسّع. الأرقام أعلاه من السعر الحي.`;
			desk.patchMessage(botId, {
				content: finalText,
				pending: false
			});
			return local;
		}
	}
	function sendDraft() {
		const text = draft.trim();
		if (!text) return;
		setDraft("");
		answerQuestion(text, false);
	}
	function listenOnce() {
		const Rec = recognitionCtor();
		if (!Rec) {
			setToast("الرسائل الصوتية تحتاج كروم على أندرويد.");
			return;
		}
		const rec = new Rec();
		rec.lang = "ar-SA";
		rec.interimResults = false;
		rec.continuous = false;
		setListening(true);
		rec.onresult = (event) => {
			const text = event.results[0]?.[0]?.transcript ?? "";
			if (text) setDraft(text);
		};
		rec.onerror = () => setListening(false);
		rec.onend = () => setListening(false);
		rec.start();
	}
	function startCall() {
		const Rec = recognitionCtor();
		setCallOpen(true);
		setCallError("");
		setCallText("");
		if (!Rec) {
			setCallError("المكالمة الصوتية تعمل من كروم على أندرويد. تقدر تحكي كتابة من المحادثة.");
			setCallStatus("الصوت غير مدعوم هنا");
			return;
		}
		const rec = new Rec();
		rec.lang = "ar-SA";
		rec.continuous = true;
		rec.interimResults = true;
		callAlive.current = true;
		busy.current = false;
		setCallStatus("يستمع");
		rec.onresult = (event) => {
			let interim = "";
			let finalText = "";
			for (let index = event.resultIndex; index < event.results.length; index++) {
				const piece = event.results[index]?.[0]?.transcript ?? "";
				if (event.results[index]?.isFinal) finalText += piece;
				else interim += piece;
			}
			if (interim) setCallText(interim);
			if (finalText.trim() && !busy.current) {
				busy.current = true;
				try {
					rec.stop();
				} catch {}
				setCallStatus("يحلّل السوق");
				setCallText(finalText.trim());
				answerQuestion(finalText.trim(), true).then(async (spoken) => {
					if (!callAlive.current) return;
					setCallStatus("يتكلم");
					await speakArabic(spoken);
					busy.current = false;
					if (!callAlive.current) return;
					setCallStatus("يستمع");
					try {
						rec.start();
					} catch {}
				});
			}
		};
		rec.onerror = () => {
			if (callAlive.current && !busy.current) setCallStatus("يستمع");
		};
		rec.onend = () => {
			if (callAlive.current && !busy.current) try {
				rec.start();
			} catch {}
		};
		rec.start();
	}
	function hangup() {
		callAlive.current = false;
		busy.current = false;
		window.speechSynthesis?.cancel();
		setCallOpen(false);
	}
	async function shareApp() {
		const payload = {
			title: BRAND,
			text: "تطبيق زادن للذهب والفوركس",
			url: window.location.href
		};
		try {
			if (navigator.share) await navigator.share(payload);
			else {
				await navigator.clipboard.writeText(window.location.href);
				setToast("تم نسخ الرابط. أرسله لأي موبايل ويفتح من كروم.");
			}
		} catch {}
	}
	async function enablePush() {
		if (typeof Notification === "undefined") {
			setToast("هذا المتصفح لا يدعم إشعار النظام. التنبيه الداخلي يبقى شغال.");
			return;
		}
		const permission = await Notification.requestPermission();
		setToast(permission === "granted" ? "إشعارات الهاتف صارت شغالة." : "ما انعطت صلاحية الإشعار. رح يضل التنبيه داخل التطبيق.");
	}
	function trackCurrent() {
		if (!signal || !quote || signal.side === "wait") {
			setToast(signal?.side === "wait" ? "ما في صفقة تستاهل المراقبة الآن." : "القراءة لسا ما جهزت.");
			return;
		}
		desk.trackTrade({
			id: `${signal.stamp}-manual`,
			symbol: quote.id,
			nameAr: quote.nameAr,
			side: signal.side,
			entryLow: signal.entryLow,
			entryHigh: signal.entryHigh,
			sl: signal.sl,
			tp1: signal.tp1,
			tp2: signal.tp2,
			openedAt: Date.now(),
			tp1Hit: false,
			result: "open"
		});
		setToast("انحطت الصفقة بالدفتر ورح تنقفل لحاله عند الهدف أو الوقف.");
	}
	if (!entered) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center bg-bg px-6 py-10 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/zadan-logo.jpg",
				alt: "شعار زادن للفوركس",
				className: "w-full max-w-sm"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-2xl font-extrabold tracking-wide text-gold-2",
				children: BRAND
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: `tel:${PHONE_TEL}`,
				className: "mt-3 text-lg font-semibold tabular-nums text-gold",
				children: PHONE_DISPLAY
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setEntered(true),
				className: "mt-8 w-full max-w-xs rounded-full bg-gold px-6 py-3 text-base font-bold text-bg",
				children: "دخول غرفة التداول"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => void shareApp(),
				className: "mt-3 inline-flex items-center gap-2 text-sm text-gold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" }), "إرسال التطبيق لموبايل ثاني"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setSheet("install"),
				className: "mt-2 text-sm text-muted",
				children: "تثبيت على أندرويد ١٠ وما فوق"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 max-w-sm text-xs leading-5 text-muted",
				children: [
					"الإصدار ",
					APP_VERSION,
					". يتحدّث وحده عند نشر نسخة جديدة، ويشتغل طالما الجهاز على الإنترنت."
				]
			}),
			sheet === "install" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallSheet, {
				installEvent,
				onClose: () => setSheet(null),
				onShare: () => void shareApp()
			}) : null
		]
	});
	const tabs = [
		{
			id: "market",
			label: "السوق",
			icon: ChartCandlestick
		},
		{
			id: "signal",
			label: "الصفقة",
			icon: Crosshair
		},
		{
			id: "chat",
			label: "دردشة",
			icon: MessageSquareText
		},
		{
			id: "news",
			label: "أخبار",
			icon: Newspaper
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex items-center gap-3 border-b border-line bg-bg/95 px-3 py-2 backdrop-blur",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setSheet("install"),
						className: "shrink-0",
						"aria-label": "التثبيت والمشاركة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/zadan-logo.jpg",
							alt: "",
							className: "size-12 object-contain"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-bold tracking-wide text-gold-2",
							children: BRAND
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `tel:${PHONE_TEL}`,
							className: "text-xs font-semibold tabular-nums text-gold",
							children: PHONE_DISPLAY
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center justify-end gap-1 text-xs text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2 rounded-full ${offline ? "bg-down" : "bg-up"}` }), offline ? "منقطع" : "مباشر"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tabular-nums text-xs text-muted",
							children: clock || "دمشق"
						})]
					})
				]
			}),
			!desk.bannerDismissed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => void enablePush().then(() => desk.dismissBanner()),
				className: "block w-full bg-surface px-4 py-2 text-start text-xs text-gold",
				children: "فعّل إشعار الفرص على الذهب والأخبار العالية. اضغط هنا."
			}) : null,
			tab === "market" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pad-nav",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketView, {
					quotes: board?.quotes ?? [],
					selected,
					series: seriesMap[selected] ?? null,
					onSelect: setSelected
				})
			}) : null,
			tab === "signal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pad-nav",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto px-4 pt-3",
					children: (board?.quotes ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setSelected(item.id),
						className: `shrink-0 rounded-full border px-3 py-1.5 text-sm ${item.id === selected ? "border-gold text-gold" : "border-line text-muted"}`,
						children: item.nameAr
					}, item.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalView, {
					quote: quote ?? null,
					signal,
					journal: desk.journal,
					onExplain: () => {
						const name = WATCH_BY_ID[selected]?.nameAr ?? "الذهب";
						setTab("chat");
						answerQuestion(`اشرح لي صفقة ${name} بالتفصيل: الدخول ووقف الخسارة وجني الأرباح والمدارس الخمسة.`, false);
					},
					onTrack: trackCurrent
				})]
			}) : null,
			tab === "chat" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatView, {
				messages: desk.messages,
				draft,
				listening,
				onDraft: setDraft,
				onSend: sendDraft,
				onMic: listenOnce,
				onSpeak: (text) => void speakArabic(text),
				onClear: desk.clearChat,
				onPrompt: (text) => void answerQuestion(text, false),
				speakOn: desk.speakOn,
				onToggleSpeak: () => desk.setSpeak(!desk.speakOn)
			}) : null,
			tab === "news" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pad-nav",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewsView, {
					events,
					now: now || Date.now(),
					alertsOn: desk.alertsOn,
					onToggleAlerts: () => desk.setAlerts(!desk.alertsOn),
					onEnablePush: () => void enablePush()
				})
			}) : null,
			toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-4 bottom-24 z-30 rounded-lg border border-gold bg-surface px-4 py-3 text-sm shadow-lg",
				children: toast
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "nav-bar fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t border-line bg-bg",
				children: [tabs.map((item) => {
					const Icon = item.icon;
					const active = tab === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTab(item.id),
						className: `flex flex-col items-center gap-1 py-2 text-xs ${active ? "text-gold" : "text-muted"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
					}, item.id);
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: startCall,
					className: "flex flex-col items-center gap-1 py-2 text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" }), "اتصال"]
				})]
			}),
			callOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallOverlay, {
				status: callStatus,
				transcript: callText,
				error: callError,
				onHangup: hangup
			}) : null,
			sheet === "install" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallSheet, {
				installEvent,
				onClose: () => setSheet(null),
				onShare: () => void shareApp()
			}) : null
		]
	});
}
function recognitionCtor() {
	if (typeof window === "undefined") return null;
	const root = window;
	return root.SpeechRecognition ?? root.webkitSpeechRecognition ?? null;
}
function InstallSheet({ installEvent, onClose, onShare }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end bg-bg/70",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full rounded-t-lg border border-line bg-surface px-5 py-5",
			onClick: (event) => event.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold",
					children: "التثبيت على الموبايل"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-6 text-muted",
					children: "أندرويد ما بيثبّت ملف exe. التطبيق يتنصّب من كروم على أندرويد ١٠ وآخر إصدار: القائمة، ثم «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية». بعدين بيفتح متل أي برنامج، وبنفس الرابط بتبعتو لأي موبايل ثاني."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-2 gap-2",
					children: [installEvent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "rounded-lg bg-gold py-3 font-semibold text-bg",
						onClick: () => void installEvent.prompt(),
						children: "تثبيت الآن"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "rounded-lg bg-gold py-3 font-semibold text-bg",
						onClick: onShare,
						children: "نسخ رابط الإرسال"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "rounded-lg border border-line py-3",
						onClick: onClose,
						children: "إغلاق"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-muted",
					children: [
						"الإصدار ",
						APP_VERSION,
						". أي تحديث بينزل لما تنشر النسخة الجديدة وتعيد فتح التطبيق."
					]
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZadanApp, {});
}
//#endregion
export { Home as component };
