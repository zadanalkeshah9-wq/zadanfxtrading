import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { a as WATCH, o as WATCH_BY_ID } from "./symbols-B3ucanza.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market-BxzrCout.js
var UA = "Mozilla/5.0 (compatible; ZadanFX/1.0)";
var boardCache = null;
var changeCache = null;
var seriesCache = /* @__PURE__ */ new Map();
var calendarCache = null;
var TITLE_AR = {
	"Non-Farm Employment Change": "الوظائف غير الزراعية",
	"Nonfarm Payrolls": "الوظائف غير الزراعية",
	"Unemployment Rate": "معدل البطالة",
	"Average Hourly Earnings m/m": "متوسط الأجور بالساعة",
	"CPI m/m": "تضخم أسعار المستهلك شهرياً",
	"CPI y/y": "تضخم أسعار المستهلك سنوياً",
	"Core CPI m/m": "التضخم الأساسي شهرياً",
	"Core CPI y/y": "التضخم الأساسي سنوياً",
	"PPI m/m": "أسعار المنتجين شهرياً",
	"Core PPI m/m": "أسعار المنتجين الأساسية",
	"FOMC Statement": "بيان الفيدرالي الأمريكي",
	"Federal Funds Rate": "قرار الفائدة الأمريكية",
	"FOMC Press Conference": "المؤتمر الصحفي للفيدرالي",
	"FOMC Meeting Minutes": "محضر اجتماع الفيدرالي",
	"GDP q/q": "النمو الاقتصادي ربع السنوي",
	"Advance GDP q/q": "القراءة المتقدمة للنمو",
	"Retail Sales m/m": "مبيعات التجزئة",
	"Core Retail Sales m/m": "مبيعات التجزئة الأساسية",
	"ISM Manufacturing PMI": "مؤشر الصناعة الأمريكي",
	"ISM Services PMI": "مؤشر الخدمات الأمريكي",
	"ADP Non-Farm Employment Change": "وظائف القطاع الخاص",
	"Initial Jobless Claims": "طلبات إعانة البطالة",
	"Crude Oil Inventories": "مخزون النفط الأمريكي",
	"ECB Press Conference": "مؤتمر البنك المركزي الأوروبي",
	"Main Refinancing Rate": "فائدة البنك المركزي الأوروبي",
	"Monetary Policy Statement": "بيان السياسة النقدية",
	"Official Bank Rate": "فائدة بنك إنجلترا",
	"BOE Gov Bailey Speaks": "تصريح محافظ بنك إنجلترا",
	"BOJ Policy Rate": "فائدة بنك اليابان",
	"Unemployment Claims": "طلبات البطالة",
	"PCE Price Index m/m": "مؤشر إنفاق المستهلك",
	"Core PCE Price Index m/m": "مؤشر الإنفاق الأساسي",
	"CB Consumer Confidence": "ثقة المستهلك",
	"Flash Manufacturing PMI": "مؤشر الصناعة السريع",
	"Flash Services PMI": "مؤشر الخدمات السريع",
	"Trade Balance": "الميزان التجاري"
};
var COUNTRY_AR = {
	USD: "الدولار",
	EUR: "اليورو",
	GBP: "الإسترليني",
	JPY: "الين",
	CAD: "الدولار الكندي",
	AUD: "الدولار الأسترالي",
	NZD: "الدولار النيوزلندي",
	CHF: "الفرنك",
	CNY: "اليوان",
	All: "عالمي",
	OIL: "النفط"
};
function goldNote(title) {
	const text = title.toLowerCase();
	if (/cpi|inflation|ppi|pce|price index/.test(text)) return "ميل تاريخي: تضخم أعلى من المتوقع يقوّي الدولار غالباً ويضغط الذهب، والرقم الأضعف يميل لدعم الذهب. ليست قاعدة ثابتة.";
	if (/non-farm|nonfarm|unemployment|jobless|adp|employment|payroll/.test(text)) return "ميل تاريخي: وظائف أقوى تدعم الدولار وقد تضغط الذهب. مفاجأة سلبية بالتوظيف غالباً تدعم الذهب قبل أن تهدأ الحركة.";
	if (/fomc|federal funds|powell|fed chair|interest rate|boe|ecb|boj|bank rate|refinancing/.test(text)) return "ميل تاريخي: لهجة متشددة أو فائدة أعلى تضغط الذهب، ولهجة ميسرة تدعمه. التقلب يقفز مع الخبر نفسه، لذلك الخطة تكون قبله وبعده لا داخله.";
	if (/gdp|retail sales|ism|pmi|consumer confidence/.test(text)) return "ميل تاريخي: نشاط أقوى من المتوقع يدعم العملة المحلية. الذهب يتفاعل غالباً عبر قوة الدولار لا عبر الخبر بمعزل.";
	if (/crude|oil|inventor/.test(text)) return "مخزون النفط يحرّك الخام مباشرة، ويصل الذهب من باب توقعات التضخم. العلاقة ليست لحظية دائماً.";
	return "راقبه إذا فاجأ السوق. الذهب يتحرك غالباً عكس مفاجآت قوة الدولار، مع استثناءات في أيام الذعر.";
}
function titleAr(title) {
	return TITLE_AR[title] ?? title;
}
async function mapPool(items, limit, fn) {
	let index = 0;
	async function worker() {
		while (index < items.length) {
			const current = items[index];
			index += 1;
			await fn(current);
		}
	}
	await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => worker()));
}
async function fetchJson(url) {
	const response = await fetch(url, { headers: {
		"User-Agent": UA,
		Accept: "application/json"
	} });
	if (!response.ok) throw new Error(`HTTP ${response.status}`);
	return response.json();
}
function pickLive(payload) {
	if (!Array.isArray(payload) || payload.length === 0) return null;
	const row = payload[0];
	const prices = row.spreadProfilePrices;
	if (!prices?.length) return null;
	const chosen = prices.find((item) => item.spreadProfile === "prime") ?? prices[0];
	const bid = Number(chosen.bid);
	const ask = Number(chosen.ask);
	if (!Number.isFinite(bid) || !Number.isFinite(ask) || ask <= 0 || bid <= 0) return null;
	return {
		bid,
		ask,
		ts: Number(row.ts) || Date.now()
	};
}
function parseYahoo(data) {
	const result = data?.chart?.result?.[0];
	if (!result) return {
		changePct: null,
		candles: []
	};
	const meta = result.meta ?? {};
	const previous = Number(meta.previousClose ?? meta.chartPreviousClose);
	const timestamps = result.timestamp ?? [];
	const quote = (result.indicators?.quote ?? [])[0];
	const candles = [];
	if (quote) for (let i = 0; i < timestamps.length; i++) {
		const o = quote.open?.[i];
		const h = quote.high?.[i];
		const l = quote.low?.[i];
		const c = quote.close?.[i];
		if (typeof o === "number" && typeof h === "number" && typeof l === "number" && typeof c === "number") candles.push({
			t: timestamps[i] * 1e3,
			o,
			h,
			l,
			c
		});
	}
	const last = candles.at(-1)?.c;
	return {
		changePct: Number.isFinite(previous) && previous > 0 && last ? (last - previous) / previous * 100 : null,
		candles
	};
}
async function loadChanges() {
	if (changeCache && Date.now() - changeCache.at < 18e4) return changeCache.data;
	const map = {};
	await mapPool(WATCH, 4, async (item) => {
		try {
			const data = await fetchJson(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(item.yahoo)}?interval=1d&range=5d`);
			map[item.id] = parseYahoo(data).changePct;
		} catch {
			map[item.id] = null;
		}
	});
	changeCache = {
		at: Date.now(),
		data: map
	};
	return map;
}
async function loadBoard() {
	if (boardCache && Date.now() - boardCache.at < 8e3) return boardCache.data;
	const changesPromise = loadChanges();
	const lives = /* @__PURE__ */ new Map();
	await mapPool(WATCH, 6, async (item) => {
		try {
			const live = pickLive(await fetchJson(`https://forex-data-feed.swissquote.com/public-quotes/bboquotes/instrument/${item.sq}`));
			if (live) lives.set(item.id, live);
		} catch {}
	});
	const changes = await changesPromise;
	const quotes = [];
	for (const item of WATCH) {
		const live = lives.get(item.id);
		if (!live) continue;
		quotes.push({
			id: item.id,
			nameAr: item.nameAr,
			unit: item.unit,
			digits: item.digits,
			kind: item.kind,
			bid: live.bid,
			ask: live.ask,
			mid: (live.bid + live.ask) / 2,
			spread: live.ask - live.bid,
			changePct: changes[item.id] ?? null,
			ts: live.ts
		});
	}
	const board = {
		quotes,
		fetchedAt: Date.now(),
		online: quotes.length > 0
	};
	if (quotes.length) boardCache = {
		at: Date.now(),
		data: board
	};
	return board;
}
async function loadSeries(id) {
	const symbol = WATCH_BY_ID[id];
	if (!symbol) throw new Error("رمز غير معروف");
	const cached = seriesCache.get(id);
	if (cached && Date.now() - cached.at < 6e4) return cached.data;
	const [liveData, yahooData] = await Promise.all([fetchJson(`https://forex-data-feed.swissquote.com/public-quotes/bboquotes/instrument/${symbol.sq}`), fetchJson(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol.yahoo)}?interval=5m&range=1d`).catch(() => null)]);
	const live = pickLive(liveData);
	let candles = (yahooData ? parseYahoo(yahooData) : {
		changePct: null,
		candles: []
	}).candles;
	let anchored = false;
	let note = "شموع ٥ دقائق.";
	if (live && candles.length) {
		const last = candles[candles.length - 1].c;
		const shift = (live.bid + live.ask) / 2 - last;
		if (last > 0 && Math.abs(shift) / last < .03) {
			candles = candles.map((candle) => ({
				t: candle.t,
				o: candle.o + shift,
				h: candle.h + shift,
				l: candle.l + shift,
				c: candle.c + shift
			}));
			anchored = true;
			note = "شموع ٥ دقائق مُحاذاة مع السعر الفوري الحالي.";
		} else note = "الشموع من العقد المرجعي، والفرق عن الفوري أكبر من المعتاد.";
	}
	const series = {
		id,
		candles,
		fetchedAt: Date.now(),
		anchored,
		note
	};
	if (candles.length) seriesCache.set(id, {
		at: Date.now(),
		data: series
	});
	return series;
}
async function loadCalendar() {
	if (calendarCache && Date.now() - calendarCache.at < 3e5) return calendarCache.data;
	const raw = await fetchJson("https://nfs.faireconomy.media/ff_calendar_thisweek.json");
	const now = Date.now();
	const events = [];
	for (const row of raw) {
		const impact = row.impact === "High" || row.impact === "Medium" || row.impact === "Low" ? row.impact : "Low";
		if (impact === "Low") continue;
		const country = row.country || "";
		if (![
			"USD",
			"EUR",
			"GBP",
			"JPY",
			"CAD",
			"AUD",
			"CHF",
			"NZD",
			"CNY"
		].includes(country)) continue;
		if (impact === "Medium" && country !== "USD") continue;
		const time = row.date ? new Date(row.date).getTime() : NaN;
		if (!Number.isFinite(time)) continue;
		if (time < now - 216e5 || time > now + 2592e5) continue;
		const title = row.title || "حدث";
		events.push({
			id: `${country}-${time}-${title}`,
			title,
			titleAr: titleAr(title),
			country,
			countryAr: COUNTRY_AR[country] ?? country,
			time,
			impact,
			forecast: row.forecast || "—",
			previous: row.previous || "—",
			goldNote: goldNote(title)
		});
	}
	events.sort((a, b) => a.time - b.time);
	const payload = {
		events: events.slice(0, 30),
		fetchedAt: Date.now()
	};
	calendarCache = {
		at: Date.now(),
		data: payload
	};
	return payload;
}
var getBoard_createServerFn_handler = createServerRpc({
	id: "2d6ca4523b718f827b9501cd1d3abb47bff448834db0ce13e62d9b2b9d09f156",
	name: "getBoard",
	filename: "src/lib/market.ts"
}, (opts) => getBoard.__executeServer(opts));
var getBoard = createServerFn({ method: "GET" }).handler(getBoard_createServerFn_handler, async () => {
	try {
		return await loadBoard();
	} catch {
		return {
			quotes: [],
			fetchedAt: Date.now(),
			online: false
		};
	}
});
var getSeries_createServerFn_handler = createServerRpc({
	id: "0a02c7bf965427f144838b6eb9ab08f45006d8b5424eb65214d8e2fc7064f71e",
	name: "getSeries",
	filename: "src/lib/market.ts"
}, (opts) => getSeries.__executeServer(opts));
var getSeries = createServerFn({ method: "GET" }).validator((input) => {
	const id = typeof input === "string" ? input : input?.id;
	if (!id || !WATCH_BY_ID[id]) throw new Error("رمز غير معروف");
	return { id };
}).handler(getSeries_createServerFn_handler, async ({ data }) => {
	try {
		return await loadSeries(data.id);
	} catch {
		return {
			id: data.id,
			candles: [],
			fetchedAt: Date.now(),
			anchored: false,
			note: "تعذر تحميل الشموع."
		};
	}
});
var getCalendar_createServerFn_handler = createServerRpc({
	id: "78d49ae487915ea572ebb0293fbbeabdc69fd3958712a7a6975a340ca1755053",
	name: "getCalendar",
	filename: "src/lib/market.ts"
}, (opts) => getCalendar.__executeServer(opts));
var getCalendar = createServerFn({ method: "GET" }).handler(getCalendar_createServerFn_handler, async () => {
	try {
		return await loadCalendar();
	} catch {
		return {
			events: [],
			fetchedAt: Date.now()
		};
	}
});
//#endregion
export { getBoard_createServerFn_handler, getCalendar_createServerFn_handler, getSeries_createServerFn_handler };
