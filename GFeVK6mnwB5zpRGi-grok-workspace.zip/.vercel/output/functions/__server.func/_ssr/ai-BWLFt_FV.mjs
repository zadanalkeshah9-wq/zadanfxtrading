import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { c as fmtPct, l as fmtPrice, o as WATCH_BY_ID, s as detectSymbol } from "./symbols-B3ucanza.mjs";
import { c as loadSeries, o as loadBoard, s as loadCalendar, t as analyze, u as nextHighImpact } from "./market-PmevV4bE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-BWLFt_FV.js
var SYSTEM = `أنت محلل غرفة ZADAN FOREX TRADING. تتكلم العربية الفصيحة البسيطة فقط، بأسلوب متداول محترف لا معلّق عام.
تتقن وتدمج عند كل إجابة لازمة: التحليل الفني، التحليل الموجي (موجات إليوت بشكل مبسط وصادق)، التحليل الكمي، التحليل الزمني للجلسات، والتحليل الأساسي للأخبار.
قواعد صارمة:
- استخدم فقط الأرقام الموجودة في لقطة السوق المرفقة. لا تخترع سعراً ولا خبراً.
- إذا طُلبت صفقة: اذكر الاتجاه (شراء أو بيع أو انتظار)، منطقة الدخول، وقف الخسارة، جني الأرباح الأول والثاني، ونقطة الإلغاء، ثم الشرح من المدارس الخمس باختصار مفيد.
- إذا كان قرار المحرك «انتظار» لا تجبر صفقة. أعطِ خطة مشروطة: ماذا يجب أن يحدث ليصبح الشراء صالحاً وماذا للبيع.
- ممنوع أن تضمن الربح أو تقول إن الصفقة بلا خسارة. التداول فيه خسارة محتملة دائماً. اذكر ذلك بجملة واحدة في إجابات الصفقات.
- إذا البيانات ناقصة قل ذلك بوضوح.
- كن سريعاً ومباشراً. بلا مقدمات مجاملة طويلة وبلا حشو.`;
var aiPaused = false;
function clip(text, max) {
	const clean = text.replace(/\s+/g, " ").trim();
	return clean.length > max ? `${clean.slice(0, max)}…` : clean;
}
function buildSnapshot(input) {
	const signal = input.signal;
	const plan = signal ? [
		`الرمز ${signal.symbol}`,
		`القرار ${signal.side === "buy" ? "شراء" : signal.side === "sell" ? "بيع" : "انتظار"}`,
		`الميل ${signal.lean}`,
		`التوافق ${signal.score}/${signal.maxScore} والحد المطلوب ${signal.minScore}`,
		`الدخول ${signal.entryLow.toFixed(3)} - ${signal.entryHigh.toFixed(3)}`,
		`وقف الخسارة ${signal.sl.toFixed(3)}`,
		`الهدف ١ ${signal.tp1.toFixed(3)}`,
		`الهدف ٢ ${signal.tp2.toFixed(3)}`,
		`ATR ${signal.atr.toFixed(4)} RSI ${signal.rsi.toFixed(1)} Z ${signal.z.toFixed(2)}`,
		`الجلسة ${signal.session}`,
		`البنية ${signal.structure}`,
		`دعم ${signal.support ?? "—"} مقاومة ${signal.resistance ?? "—"}`,
		`الأسباب: ${signal.reasons.join(" | ") || "—"}`,
		`الموانع: ${signal.blockers.join(" | ") || "—"}`,
		...signal.schools.map((school) => `${school.name}: ${school.note}`)
	].join("\n") : "لا توجد قراءة شموع كافية.";
	return [
		`الرمز المطلوب: ${input.focus} (${WATCH_BY_ID[input.focus]?.nameAr ?? input.focus})`,
		"الأسعار الفورية:",
		input.boardLines,
		input.candlesNote,
		"قراءة المحرك:",
		plan,
		"الأخبار:",
		input.events || "لا أحداث قريبة في التقويم.",
		"دفتر الصفقات على هذا الجهاز:",
		input.journal || "لا صفقات مسجّلة بعد."
	].join("\n");
}
async function completeWithGrok(messages) {
	if (aiPaused) return {
		ok: false,
		error: "الشرح الموسّع متوقف حالياً لأن رصيد الذكاء خلص. القراءة فوق من الشارت الحي وتبقى شغالة."
	};
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "الشرح الموسّع غير متاح في هذه البيئة. القراءة فوق من الشارت الحي."
	};
	try {
		const response = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .2,
				max_tokens: 900,
				messages
			})
		});
		if (!response.ok) {
			const detail = await response.text();
			if (response.status === 403 || detail.includes("spending-limit") || detail.includes("credits")) {
				aiPaused = true;
				return {
					ok: false,
					error: "الشرح الموسّع متوقف حالياً لأن رصيد الذكاء خلص. الأرقام والقرار فوق من الشارت الحي، بدون ما يتوقف التحديث."
				};
			}
			return {
				ok: false,
				error: "تعذر إكمال الشرح الموسّع الآن. الأرقام فوق من السعر الحي."
			};
		}
		const text = (await response.json()).choices?.[0]?.message?.content?.trim() ?? "";
		if (!text) return {
			ok: false,
			error: "وصل رد فارغ. اعتمد القراءة الرقمية فوق."
		};
		return {
			ok: true,
			text
		};
	} catch {
		return {
			ok: false,
			error: "انقطع الاتصال أثناء الشرح الموسّع. القراءة الرقمية فوق قائمة."
		};
	}
}
var askAnalyst_createServerFn_handler = createServerRpc({
	id: "f935ff5a01f4a7105bdda1cdf6770454c5c049b2a8f235ef4cf93438679500f6",
	name: "askAnalyst",
	filename: "src/lib/ai.ts"
}, (opts) => askAnalyst.__executeServer(opts));
var askAnalyst = createServerFn({ method: "POST" }).validator((input) => {
	const body = input;
	if (!body || typeof body.question !== "string" || body.question.trim().length < 1) throw new Error("اكتب سؤالاً");
	const history = [];
	if (Array.isArray(body.history)) for (const turn of body.history.slice(-8)) {
		const row = turn;
		if ((row.role === "user" || row.role === "assistant") && typeof row.content === "string") history.push({
			role: row.role,
			content: clip(row.content, 1200)
		});
	}
	const journal = typeof body.journal === "string" ? clip(body.journal, 800) : "";
	const minScore = body.minScore === 6 ? 6 : 5;
	return {
		question: clip(body.question, 2e3),
		history,
		journal,
		minScore
	};
}).handler(askAnalyst_createServerFn_handler, async ({ data }) => {
	const focus = detectSymbol(data.question);
	const [board, calendar] = await Promise.all([loadBoard(), loadCalendar()]);
	let seriesNote = "الشموع غير متاحة.";
	let signal = null;
	const quote = board.quotes.find((item) => item.id === focus) ?? null;
	try {
		const series = await loadSeries(focus);
		seriesNote = `${series.note} عدد الشموع ${series.candles.length}.`;
		if (quote && series.candles.length >= 20) signal = analyze({
			quote,
			candles: series.candles,
			nextHigh: nextHighImpact(calendar.events),
			minScore: data.minScore
		});
	} catch {
		seriesNote = "تعذر قراءة الشموع هذه اللحظة.";
	}
	const boardLines = board.quotes.map((item) => `${item.nameAr} ${item.id} شراء ${fmtPrice(item.bid, item.digits)} بيع ${fmtPrice(item.ask, item.digits)} اليوم ${fmtPct(item.changePct)}`).join("\n");
	const events = calendar.events.slice(0, 8).map((event) => {
		return `${new Intl.DateTimeFormat("ar-SY", {
			timeZone: "Asia/Damascus",
			month: "short",
			day: "numeric",
			hour: "2-digit",
			minute: "2-digit"
		}).format(event.time)} | ${event.countryAr} | ${event.impact === "High" ? "عالي" : "متوسط"} | ${event.titleAr} | السابق ${event.previous} المتوقع ${event.forecast}`;
	}).join("\n");
	const snapshot = buildSnapshot({
		focus,
		boardLines,
		signal,
		candlesNote: seriesNote,
		events,
		journal: data.journal
	});
	const completion = await completeWithGrok([
		{
			role: "system",
			content: SYSTEM
		},
		{
			role: "system",
			content: snapshot
		},
		...data.history.map((turn) => ({
			role: turn.role,
			content: turn.content
		})),
		{
			role: "user",
			content: data.question
		}
	]);
	if (!completion.ok) return {
		ok: false,
		error: completion.error,
		focus,
		signal
	};
	return {
		ok: true,
		text: completion.text,
		focus,
		signal
	};
});
//#endregion
export { askAnalyst_createServerFn_handler };
