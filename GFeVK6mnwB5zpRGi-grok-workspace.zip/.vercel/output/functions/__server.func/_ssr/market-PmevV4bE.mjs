import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as WATCH, o as WATCH_BY_ID } from "./symbols-B3ucanza.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market-PmevV4bE.js
function avg(values) {
	if (!values.length) return 0;
	return values.reduce((sum, value) => sum + value, 0) / values.length;
}
function ema(values, period) {
	const out = new Array(values.length).fill(NaN);
	if (values.length < period) return out;
	const k = 2 / (period + 1);
	let prev = avg(values.slice(0, period));
	out[period - 1] = prev;
	for (let i = period; i < values.length; i++) {
		prev = values[i] * k + prev * (1 - k);
		out[i] = prev;
	}
	return out;
}
function rsi(values, period = 14) {
	if (values.length < period + 1) return 50;
	let gains = 0;
	let losses = 0;
	for (let i = values.length - period; i < values.length; i++) {
		const delta = values[i] - values[i - 1];
		if (delta >= 0) gains += delta;
		else losses -= delta;
	}
	if (losses === 0) return 100;
	return 100 - 100 / (1 + gains / losses);
}
function atr(candles, period = 14) {
	const trs = [];
	for (let i = 1; i < candles.length; i++) {
		const current = candles[i];
		const prev = candles[i - 1];
		trs.push(Math.max(current.h - current.l, Math.abs(current.h - prev.c), Math.abs(current.l - prev.c)));
	}
	return avg(trs.slice(-period)) || (candles.at(-1)?.c ?? 1) * .002;
}
function swings(candles, threshold) {
	const points = [];
	if (candles.length < 5) return points;
	let extreme = candles[0].c;
	let extremeIndex = 0;
	let dir = null;
	for (let i = 1; i < candles.length; i++) {
		const price = candles[i].c;
		if (dir !== "down" && extreme - price >= threshold) {
			points.push({
				index: extremeIndex,
				price: extreme,
				kind: "high"
			});
			dir = "down";
			extreme = price;
			extremeIndex = i;
		} else if (dir !== "up" && price - extreme >= threshold) {
			points.push({
				index: extremeIndex,
				price: extreme,
				kind: "low"
			});
			dir = "up";
			extreme = price;
			extremeIndex = i;
		} else if (dir === "down" && price < extreme) {
			extreme = price;
			extremeIndex = i;
		} else if ((dir === "up" || dir === null) && price > extreme) {
			extreme = price;
			extremeIndex = i;
		} else if (dir === null && price < extreme) {
			extreme = price;
			extremeIndex = i;
		}
	}
	return points.slice(-6);
}
function damascusHour(now = /* @__PURE__ */ new Date()) {
	const hour = new Intl.DateTimeFormat("en-GB", {
		timeZone: "Asia/Damascus",
		hour: "numeric",
		hourCycle: "h23"
	}).format(now);
	return Number(hour);
}
function sessionNow(now = /* @__PURE__ */ new Date()) {
	const hour = damascusHour(now);
	if (hour >= 16 && hour < 19) return {
		name: "تداخل لندن ونيويورك",
		quality: "high"
	};
	if (hour >= 10 && hour < 16) return {
		name: "جلسة لندن",
		quality: "high"
	};
	if (hour >= 19 || hour < 1) return {
		name: "جلسة نيويورك",
		quality: "mid"
	};
	return {
		name: "جلسة آسيا",
		quality: "low"
	};
}
function roundStep(symbol) {
	if (symbol === "XAUUSD") return 10;
	if (symbol === "XAGUSD") return .5;
	if (symbol === "OILUSD") return 1;
	if (symbol === "USDJPY" || symbol === "USDTRY") return .5;
	return .005;
}
function distToRound(price, step) {
	const rounded = Math.round(price / step) * step;
	return Math.abs(price - rounded);
}
function minScoreFromJournal(results) {
	const done = results.filter((item) => item === "win" || item === "loss" || item === "partial");
	if (done.length < 5) return 5;
	if (done.filter((item) => item === "win" || item === "partial").length / done.length < .45) return 6;
	return 5;
}
function analyze(input) {
	const { quote, candles } = input;
	const minScore = input.minScore ?? 5;
	const maxScore = 7;
	const now = input.now ?? Date.now();
	const session = sessionNow(new Date(now));
	const closes = candles.map((candle) => candle.c);
	const last = quote.mid;
	const ema20 = ema(closes, 20).at(-1);
	const ema50 = ema(closes, 50).at(-1);
	const rsiValue = rsi(closes);
	const atrValue = atr(candles);
	const swing = swings(candles, atrValue * .85);
	const highs = swing.filter((point) => point.kind === "high").slice(-2);
	const lows = swing.filter((point) => point.kind === "low").slice(-2);
	let structure = "البنية العرضية غالبة، ما في موجة واضحة.";
	let structureLean = "flat";
	if (highs.length >= 2 && lows.length >= 2) {
		const hh = highs[1].price > highs[0].price;
		const hl = lows[1].price > lows[0].price;
		const lh = highs[1].price < highs[0].price;
		const ll = lows[1].price < lows[0].price;
		if (hh && hl) {
			structure = "قمم وقيعان صاعدة: موجة دافعة صاعدة محتملة.";
			structureLean = "buy";
		} else if (lh && ll) {
			structure = "قمم وقيعان هابطة: موجة دافعة هابطة محتملة.";
			structureLean = "sell";
		} else if (hh && ll) structure = "اتساع بالنطاق، الموجة التصحيحية أرجح من الدفع.";
		else structure = "تداخل قمم وقيعان، السوق تصحيحي أو عرضي.";
	}
	const support = lows.at(-1)?.price ?? null;
	const resistance = highs.at(-1)?.price ?? null;
	const returns = [];
	for (let i = Math.max(1, closes.length - 30); i < closes.length; i++) returns.push((closes[i] - closes[i - 1]) / closes[i - 1]);
	const mean = avg(returns);
	const variance = avg(returns.map((value) => (value - mean) ** 2));
	const sd = Math.sqrt(variance);
	const z = sd ? (returns.at(-1) - mean) / sd : 0;
	let lean = "flat";
	if (ema20 != null && ema50 != null && Number.isFinite(ema20) && Number.isFinite(ema50)) {
		if (last > ema20 && ema20 >= ema50) lean = "buy";
		else if (last < ema20 && ema20 <= ema50) lean = "sell";
	}
	if (lean === "flat") lean = structureLean;
	const imminent = input.nextHigh != null && input.nextHigh.time - now < 12e5 && input.nextHigh.time > now;
	const trendOk = lean !== "flat" && ema20 != null && ema50 != null && (lean === "buy" && last >= ema50 || lean === "sell" && last <= ema50);
	const distEma = ema20 != null && Number.isFinite(ema20) ? Math.abs(last - ema20) : atrValue;
	const chasing = distEma > atrValue * 1.15 || Math.abs(z) > 2;
	const pullback = distEma <= atrValue * .75 && !chasing;
	const rsiOk = lean === "buy" ? rsiValue >= 40 && rsiValue <= 64 : lean === "sell" ? rsiValue >= 36 && rsiValue <= 60 : false;
	const structureOk = structureLean === lean && lean !== "flat";
	const sessionOk = session.quality !== "low";
	const newsOk = !imminent;
	const quantOk = Math.abs(z) < 1.8;
	const flags = [
		{
			ok: trendOk,
			good: "الاتجاه القصير متوافق مع المتوسطات",
			bad: "المتوسطات غير متوافقة مع اتجاه واضح"
		},
		{
			ok: pullback,
			good: "السعر قرب المتوسط، ليست مطاردة",
			bad: chasing ? "السعر ممتد ومطاردة الدخول ضعيفة" : "السعر بعيد عن منطقة الدخول الهادئة"
		},
		{
			ok: rsiOk,
			good: `القوة النسبية ${rsiValue.toFixed(0)} داخل نطاق صالح`,
			bad: `القوة النسبية ${rsiValue.toFixed(0)} خارج النطاق المفضل`
		},
		{
			ok: structureOk,
			good: "بنية القمم والقيعان تؤيد الاتجاه",
			bad: "بنية الموجة لا تؤكد الاتجاه"
		},
		{
			ok: sessionOk,
			good: `${session.name} فيها سيولة أفضل`,
			bad: `${session.name} هادئة والحركة أقل مصداقية`
		},
		{
			ok: newsOk,
			good: "لا خبر عالي خلال الدقائق القادمة",
			bad: "خبر عالي التأثير قريب، الدخول قبل الخبر مقامرة"
		},
		{
			ok: quantOk,
			good: "الامتداد الكمي طبيعي",
			bad: "الامتداد الإحصائي مرتفع"
		}
	];
	const score = flags.filter((flag) => flag.ok).length;
	const reasons = flags.filter((flag) => flag.ok).map((flag) => flag.good);
	const blockers = flags.filter((flag) => !flag.ok).map((flag) => flag.bad);
	if (candles.length < 40) blockers.unshift("عدد الشموع غير كافٍ لقراءة موثوقة");
	if (imminent && input.nextHigh) blockers.unshift(`خبر قريب: ${input.nextHigh.titleAr}`);
	const side = candles.length >= 40 && lean !== "flat" && score >= minScore && !imminent && !chasing ? lean : "wait";
	const swingLow = support ?? last - atrValue;
	const swingHigh = resistance ?? last + atrValue;
	const entryPad = atrValue * .18;
	let entryLow = last - entryPad;
	let entryHigh = last + entryPad * .4;
	let sl = swingLow - atrValue * .35;
	let tp1 = last + (last - sl) * 1.6;
	let tp2 = last + (last - sl) * 2.5;
	if (lean === "sell") {
		entryLow = last - entryPad * .4;
		entryHigh = last + entryPad;
		sl = swingHigh + atrValue * .35;
		const risk = sl - last;
		tp1 = last - risk * 1.6;
		tp2 = last - risk * 2.5;
	}
	if (Math.abs((lean === "sell" ? entryHigh : entryLow) - sl) > atrValue * 2.4) {
		if (lean === "sell") sl = last + atrValue * 1.35;
		else sl = last - atrValue * 1.35;
		const tight = Math.abs(last - sl);
		if (lean === "sell") {
			tp1 = last - tight * 1.6;
			tp2 = last - tight * 2.5;
		} else {
			tp1 = last + tight * 1.6;
			tp2 = last + tight * 2.5;
		}
	}
	const timeNote = distToRound(last, roundStep(quote.id)) < atrValue * .2 ? `${session.name}. السعر ملاصق لرقم مدوّر، وهي منطقة ردة فعل زمنية شائعة.` : `${session.name} بتوقيت دمشق. ${session.quality === "high" ? "هذه النافذة عادة أنشط للذهب والعملات." : session.quality === "mid" ? "السيولة مقبولة، لكن الزخم أهدأ من تداخل الجلسات." : "جلسة آسيا أهدأ. الصفقات القوية تُفضَّل مع لندن أو نيويورك."}`;
	const eventNote = input.nextHigh ? `أقرب خبر عالي: ${input.nextHigh.titleAr} (${input.nextHigh.countryAr}). ${input.nextHigh.goldNote}` : "لا خبر عالي التأثير ضمن الساعات القريبة. الوزن الأساسي أخف من الفني الآن.";
	const waveNote = structureLean === "buy" ? "عدّ موجي مبسط: دفع صاعد محتمل. التأكيد يكسر آخر قمة، والإلغاء يكسر آخر قاع." : structureLean === "sell" ? "عدّ موجي مبسط: دفع هابط محتمل. التأكيد يكسر آخر قاع، والإلغاء يعود فوق آخر قمة." : "العد الموجي غير ناضج. التعامل معها كتصحيح أفضل من فرض موجة دافعة.";
	const schools = [
		{
			name: "التحليل الفني",
			note: `المتوسط ٢٠ ${ema20 != null && Number.isFinite(ema20) ? ema20.toFixed(quote.digits) : "—"} والمتوسط ٥٠ ${ema50 != null && Number.isFinite(ema50) ? ema50.toFixed(quote.digits) : "—"}. القوة النسبية ${rsiValue.toFixed(0)}. الدعم القريب ${support?.toFixed(quote.digits) ?? "—"} والمقاومة ${resistance?.toFixed(quote.digits) ?? "—"}.`
		},
		{
			name: "التحليل الموجي",
			note: `${structure} ${waveNote}`
		},
		{
			name: "التحليل الكمي",
			note: `درجة الامتداد Z = ${z.toFixed(2)}. مدى متوسط حقيقي ${atrValue.toFixed(quote.digits)}. ${Math.abs(z) > 1.8 ? "الحركة ممتدة إحصائياً، انتظار عودة أفضل من اللحاق." : "التذبذب ضمن نطاق قابل للقياس."}`
		},
		{
			name: "التحليل الزمني",
			note: timeNote
		},
		{
			name: "التحليل الأساسي",
			note: eventNote
		}
	];
	const bucket = new Date(now);
	bucket.setMinutes(0, 0, 0);
	const stamp = `${quote.id}-${side}-${bucket.getTime()}`;
	return {
		symbol: quote.id,
		side,
		lean,
		score,
		maxScore,
		minScore,
		entryLow: Math.min(entryLow, entryHigh),
		entryHigh: Math.max(entryLow, entryHigh),
		sl,
		tp1,
		tp2,
		atr: atrValue,
		rsi: rsiValue,
		z,
		session: session.name,
		sessionQuality: session.quality,
		structure,
		reasons,
		blockers,
		schools,
		support,
		resistance,
		stamp
	};
}
function nextHighImpact(events, now = Date.now()) {
	return events.find((event) => event.impact === "High" && event.time > now - 3e5) ?? null;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var UA = "Mozilla/5.0 (compatible; ZadanFX/1.0)";
var boardCache = null;
var changeCache = null;
var seriesCache = /* @__PURE__ */ new Map();
var calendarCache = null;
var TITLE_AR = {
	"Non-Farm Employment Change": "الوظائف غير الزراعية",
	"Nonfarm Payrolls": "الوظائف غير الزراعية",
	"Unemployment Rate": "معدل البطالة",
	"Average Hourly Earnings m/m": "متوسط الأجور بالساعة",
	"CPI m/m": "تضخم أسعار المستهلك شهرياً",
	"CPI y/y": "تضخم أسعار المستهلك سنوياً",
	"Core CPI m/m": "التضخم الأساسي شهرياً",
	"Core CPI y/y": "التضخم الأساسي سنوياً",
	"PPI m/m": "أسعار المنتجين شهرياً",
	"Core PPI m/m": "أسعار المنتجين الأساسية",
	"FOMC Statement": "بيان الفيدرالي الأمريكي",
	"Federal Funds Rate": "قرار الفائدة الأمريكية",
	"FOMC Press Conference": "المؤتمر الصحفي للفيدرالي",
	"FOMC Meeting Minutes": "محضر اجتماع الفيدرالي",
	"GDP q/q": "النمو الاقتصادي ربع السنوي",
	"Advance GDP q/q": "القراءة المتقدمة للنمو",
	"Retail Sales m/m": "مبيعات التجزئة",
	"Core Retail Sales m/m": "مبيعات التجزئة الأساسية",
	"ISM Manufacturing PMI": "مؤشر الصناعة الأمريكي",
	"ISM Services PMI": "مؤشر الخدمات الأمريكي",
	"ADP Non-Farm Employment Change": "وظائف القطاع الخاص",
	"Initial Jobless Claims": "طلبات إعانة البطالة",
	"Crude Oil Inventories": "مخزون النفط الأمريكي",
	"ECB Press Conference": "مؤتمر البنك المركزي الأوروبي",
	"Main Refinancing Rate": "فائدة البنك المركزي الأوروبي",
	"Monetary Policy Statement": "بيان السياسة النقدية",
	"Official Bank Rate": "فائدة بنك إنجلترا",
	"BOE Gov Bailey Speaks": "تصريح محافظ بنك إنجلترا",
	"BOJ Policy Rate": "فائدة بنك اليابان",
	"Unemployment Claims": "طلبات البطالة",
	"PCE Price Index m/m": "مؤشر إنفاق المستهلك",
	"Core PCE Price Index m/m": "مؤشر الإنفاق الأساسي",
	"CB Consumer Confidence": "ثقة المستهلك",
	"Flash Manufacturing PMI": "مؤشر الصناعة السريع",
	"Flash Services PMI": "مؤشر الخدمات السريع",
	"Trade Balance": "الميزان التجاري"
};
var COUNTRY_AR = {
	USD: "الدولار",
	EUR: "اليورو",
	GBP: "الإسترليني",
	JPY: "الين",
	CAD: "الدولار الكندي",
	AUD: "الدولار الأسترالي",
	NZD: "الدولار النيوزلندي",
	CHF: "الفرنك",
	CNY: "اليوان",
	All: "عالمي",
	OIL: "النفط"
};
function goldNote(title) {
	const text = title.toLowerCase();
	if (/cpi|inflation|ppi|pce|price index/.test(text)) return "ميل تاريخي: تضخم أعلى من المتوقع يقوّي الدولار غالباً ويضغط الذهب، والرقم الأضعف يميل لدعم الذهب. ليست قاعدة ثابتة.";
	if (/non-farm|nonfarm|unemployment|jobless|adp|employment|payroll/.test(text)) return "ميل تاريخي: وظائف أقوى تدعم الدولار وقد تضغط الذهب. مفاجأة سلبية بالتوظيف غالباً تدعم الذهب قبل أن تهدأ الحركة.";
	if (/fomc|federal funds|powell|fed chair|interest rate|boe|ecb|boj|bank rate|refinancing/.test(text)) return "ميل تاريخي: لهجة متشددة أو فائدة أعلى تضغط الذهب، ولهجة ميسرة تدعمه. التقلب يقفز مع الخبر نفسه، لذلك الخطة تكون قبله وبعده لا داخله.";
	if (/gdp|retail sales|ism|pmi|consumer confidence/.test(text)) return "ميل تاريخي: نشاط أقوى من المتوقع يدعم العملة المحلية. الذهب يتفاعل غالباً عبر قوة الدولار لا عبر الخبر بمعزل.";
	if (/crude|oil|inventor/.test(text)) return "مخزون النفط يحرّك الخام مباشرة، ويصل الذهب من باب توقعات التضخم. العلاقة ليست لحظية دائماً.";
	return "راقبه إذا فاجأ السوق. الذهب يتحرك غالباً عكس مفاجآت قوة الدولار، مع استثناءات في أيام الذعر.";
}
function titleAr(title) {
	return TITLE_AR[title] ?? title;
}
async function mapPool(items, limit, fn) {
	let index = 0;
	async function worker() {
		while (index < items.length) {
			const current = items[index];
			index += 1;
			await fn(current);
		}
	}
	await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => worker()));
}
async function fetchJson(url) {
	const response = await fetch(url, { headers: {
		"User-Agent": UA,
		Accept: "application/json"
	} });
	if (!response.ok) throw new Error(`HTTP ${response.status}`);
	return response.json();
}
function pickLive(payload) {
	if (!Array.isArray(payload) || payload.length === 0) return null;
	const row = payload[0];
	const prices = row.spreadProfilePrices;
	if (!prices?.length) return null;
	const chosen = prices.find((item) => item.spreadProfile === "prime") ?? prices[0];
	const bid = Number(chosen.bid);
	const ask = Number(chosen.ask);
	if (!Number.isFinite(bid) || !Number.isFinite(ask) || ask <= 0 || bid <= 0) return null;
	return {
		bid,
		ask,
		ts: Number(row.ts) || Date.now()
	};
}
function parseYahoo(data) {
	const result = data?.chart?.result?.[0];
	if (!result) return {
		changePct: null,
		candles: []
	};
	const meta = result.meta ?? {};
	const previous = Number(meta.previousClose ?? meta.chartPreviousClose);
	const timestamps = result.timestamp ?? [];
	const quote = (result.indicators?.quote ?? [])[0];
	const candles = [];
	if (quote) for (let i = 0; i < timestamps.length; i++) {
		const o = quote.open?.[i];
		const h = quote.high?.[i];
		const l = quote.low?.[i];
		const c = quote.close?.[i];
		if (typeof o === "number" && typeof h === "number" && typeof l === "number" && typeof c === "number") candles.push({
			t: timestamps[i] * 1e3,
			o,
			h,
			l,
			c
		});
	}
	const last = candles.at(-1)?.c;
	return {
		changePct: Number.isFinite(previous) && previous > 0 && last ? (last - previous) / previous * 100 : null,
		candles
	};
}
async function loadChanges() {
	if (changeCache && Date.now() - changeCache.at < 18e4) return changeCache.data;
	const map = {};
	await mapPool(WATCH, 4, async (item) => {
		try {
			const data = await fetchJson(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(item.yahoo)}?interval=1d&range=5d`);
			map[item.id] = parseYahoo(data).changePct;
		} catch {
			map[item.id] = null;
		}
	});
	changeCache = {
		at: Date.now(),
		data: map
	};
	return map;
}
async function loadBoard() {
	if (boardCache && Date.now() - boardCache.at < 8e3) return boardCache.data;
	const changesPromise = loadChanges();
	const lives = /* @__PURE__ */ new Map();
	await mapPool(WATCH, 6, async (item) => {
		try {
			const live = pickLive(await fetchJson(`https://forex-data-feed.swissquote.com/public-quotes/bboquotes/instrument/${item.sq}`));
			if (live) lives.set(item.id, live);
		} catch {}
	});
	const changes = await changesPromise;
	const quotes = [];
	for (const item of WATCH) {
		const live = lives.get(item.id);
		if (!live) continue;
		quotes.push({
			id: item.id,
			nameAr: item.nameAr,
			unit: item.unit,
			digits: item.digits,
			kind: item.kind,
			bid: live.bid,
			ask: live.ask,
			mid: (live.bid + live.ask) / 2,
			spread: live.ask - live.bid,
			changePct: changes[item.id] ?? null,
			ts: live.ts
		});
	}
	const board = {
		quotes,
		fetchedAt: Date.now(),
		online: quotes.length > 0
	};
	if (quotes.length) boardCache = {
		at: Date.now(),
		data: board
	};
	return board;
}
async function loadSeries(id) {
	const symbol = WATCH_BY_ID[id];
	if (!symbol) throw new Error("رمز غير معروف");
	const cached = seriesCache.get(id);
	if (cached && Date.now() - cached.at < 6e4) return cached.data;
	const [liveData, yahooData] = await Promise.all([fetchJson(`https://forex-data-feed.swissquote.com/public-quotes/bboquotes/instrument/${symbol.sq}`), fetchJson(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol.yahoo)}?interval=5m&range=1d`).catch(() => null)]);
	const live = pickLive(liveData);
	let candles = (yahooData ? parseYahoo(yahooData) : {
		changePct: null,
		candles: []
	}).candles;
	let anchored = false;
	let note = "شموع ٥ دقائق.";
	if (live && candles.length) {
		const last = candles[candles.length - 1].c;
		const shift = (live.bid + live.ask) / 2 - last;
		if (last > 0 && Math.abs(shift) / last < .03) {
			candles = candles.map((candle) => ({
				t: candle.t,
				o: candle.o + shift,
				h: candle.h + shift,
				l: candle.l + shift,
				c: candle.c + shift
			}));
			anchored = true;
			note = "شموع ٥ دقائق مُحاذاة مع السعر الفوري الحالي.";
		} else note = "الشموع من العقد المرجعي، والفرق عن الفوري أكبر من المعتاد.";
	}
	const series = {
		id,
		candles,
		fetchedAt: Date.now(),
		anchored,
		note
	};
	if (candles.length) seriesCache.set(id, {
		at: Date.now(),
		data: series
	});
	return series;
}
async function loadCalendar() {
	if (calendarCache && Date.now() - calendarCache.at < 3e5) return calendarCache.data;
	const raw = await fetchJson("https://nfs.faireconomy.media/ff_calendar_thisweek.json");
	const now = Date.now();
	const events = [];
	for (const row of raw) {
		const impact = row.impact === "High" || row.impact === "Medium" || row.impact === "Low" ? row.impact : "Low";
		if (impact === "Low") continue;
		const country = row.country || "";
		if (![
			"USD",
			"EUR",
			"GBP",
			"JPY",
			"CAD",
			"AUD",
			"CHF",
			"NZD",
			"CNY"
		].includes(country)) continue;
		if (impact === "Medium" && country !== "USD") continue;
		const time = row.date ? new Date(row.date).getTime() : NaN;
		if (!Number.isFinite(time)) continue;
		if (time < now - 216e5 || time > now + 2592e5) continue;
		const title = row.title || "حدث";
		events.push({
			id: `${country}-${time}-${title}`,
			title,
			titleAr: titleAr(title),
			country,
			countryAr: COUNTRY_AR[country] ?? country,
			time,
			impact,
			forecast: row.forecast || "—",
			previous: row.previous || "—",
			goldNote: goldNote(title)
		});
	}
	events.sort((a, b) => a.time - b.time);
	const payload = {
		events: events.slice(0, 30),
		fetchedAt: Date.now()
	};
	calendarCache = {
		at: Date.now(),
		data: payload
	};
	return payload;
}
var getBoard = createServerFn({ method: "GET" }).handler(createSsrRpc("2d6ca4523b718f827b9501cd1d3abb47bff448834db0ce13e62d9b2b9d09f156"));
var getSeries = createServerFn({ method: "GET" }).validator((input) => {
	const id = typeof input === "string" ? input : input?.id;
	if (!id || !WATCH_BY_ID[id]) throw new Error("رمز غير معروف");
	return { id };
}).handler(createSsrRpc("0a02c7bf965427f144838b6eb9ab08f45006d8b5424eb65214d8e2fc7064f71e"));
var getCalendar = createServerFn({ method: "GET" }).handler(createSsrRpc("78d49ae487915ea572ebb0293fbbeabdc69fd3958712a7a6975a340ca1755053"));
//#endregion
export { getSeries as a, loadSeries as c, getCalendar as i, minScoreFromJournal as l, createSsrRpc as n, loadBoard as o, getBoard as r, loadCalendar as s, analyze as t, nextHighImpact as u };
