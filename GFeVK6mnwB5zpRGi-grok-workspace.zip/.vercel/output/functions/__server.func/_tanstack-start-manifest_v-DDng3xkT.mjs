//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DDng3xkT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-OomdWvQl.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-OomdWvQl.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-d38YGqUT.js"]
	}
} });
//#endregion
export { tsrStartManifest };
